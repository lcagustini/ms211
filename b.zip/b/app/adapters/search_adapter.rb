class SearchAdapter
  def initialize(params)
    @query = "%#{params}%"
  end

  def page
    Page.where("content LIKE ?", @query)
  end

  def news
    News.where("(content LIKE ?) OR (title LIKE ?)", @query, @query)
  end

  def product
    Product.where("(name LIKE ? OR description LIKE ? OR features LIKE ? OR code LIKE ? OR meta_keywords LIKE ?) AND status = true ", @query, @query, @query, @query, @query )
  end

  def category
    Product.joins(:category).where("(categories.name LIKE ?) AND products.status = true", @query)
  end

  def total_of_results
    page.size + news.size + product.size + category.size
  end

  def results
    page + news + product + category
  end
  
end
