# -*- encoding: utf-8 -*-
class ContactsController < ApplicationController
  layout "contact"

  def new
    @meta_title = "Alpex | Fale Conosco"
    @contact = SiteContact.new
    respond_with @contact
  end

  def create
    @meta_title = "Alpex | Fale Conosco"
    @contact = SiteContact.new(params[:site_contact])
    @contact.contact_type = ContactType::CONTACT

    if @contact.valid? == true
      @contact.save
      NotificationMailer.contact_form(params[:site_contact]).deliver
    else
      render :new
    end
  end
end
