# -*- encoding: utf-8 -*-
class SendPageController < ApplicationController
  layout "no_submenu"

  def index
    @meta_title = "Alpex - Envie para um amigo"
    @pages = SendPageQueue.where("session_id = ?", request.session_options[:id]).select("title, url").uniq
    
    @cont = 1
    @session_pages = ""

    if @pages.count > 0
      @session_pages << "Indico que você veja as páginas:\n\n"

      @pages.each do |page|
        @session_pages += @cont.to_s + ". " + page.title + " - " + page.url + "\n"
        @cont = @cont + 1
      end
    end

    @session_pages << "\n\n"

    @products_apa = Product.where(:id => session[:apa_products_send_to_friend_basket]).reorder("products.name")
    @products_ape = Product.where(:id => session[:ape_products_send_to_friend_basket]).reorder("products.code")

    if @products_apa.count > 0
      @session_pages << "Indico que você veja os produtos:" << "\n\n"

      @product_count = 1

      @products_apa.each_with_index do |product,index|
        @session_pages << "#{@product_count}. " << product.name << " no link " << "http://www.alpex.com.br" << products_apa_path(product) << "\n"

        @product_count = @product_count + 1
      end

      @session_pages << "\n\n"
    end

    if @products_ape.count > 0
      @session_pages << "Indico que você veja os produtos:" << "\n\n"

      @product_count = 1

      @products_ape.each_with_index do |product,index|
        @session_pages << "#{@product_count}. Indico que você veja o produto " << product.code << " no link " << "http://www.alpex.com.br" << products_ape_path(product) << "\n"

        @product_count = @product_count + 1
      end
    end    
  end

  def create
    @meta_title = "Alpex | Envie para um amigo"

    if ( (params[:nome].present?)&&(params[:seu_email].present?)&&(params[:email_amigo].present?) )
      @vars = [ ["Nome",params[:nome]],["Seu E-mail",params[:seu_email]],["Email do Amigo",params[:email_amigo]],["Páginas Indicadas",params[:message] ] ]
      NotificationMailer.send_page(@vars).deliver
      SendPageQueue.where("session_id = ?", request.session_options[:id]).destroy_all
      session[:ape_products_send_to_friend_basket] = nil
      session[:apa_products_send_to_friend_basket] = nil
    else
      flash[:notice] = "Preencha todos os CAMPOS!"
    end
    
  end
end
