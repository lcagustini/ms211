# -*- encoding: utf-8 -*-
class ReleasesAllController < ApplicationController
  layout "release"

  def index
    @meta_title = "Alpex - Lançamentos"

    @ape_releases_count = Product.releases.ape.count
    @apa_releases_count = Product.releases.apa.count
  end
end
