# -*- encoding: utf-8 -*-
class Admin::SiteContactsController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    @site_contacts = SiteContact.all
    
    respond_to do |format|
      format.html
      format.csv do
        filename = "Contatos - " + I18n.l(Time.now, :format => :short) + ".csv"

        report_csv = CSV.generate do |csv|
          # header row
          csv << ["Envio em", "Área de Interesse", "Unidade", "Nome", "Email", "Telefone", "Empresa", "Mensagem"]

          # data rows
          @site_contacts.each do |data|
            department_sent = ""
            unit = ""

            department_sent = data.department_sent_humanize if data.department_sent.present?
            unit = data.unit_humanize if data.unit.present?

            csv << [I18n.l(data.created_at), department_sent, unit, data.name, data.email, data.phone, data.organization, data.message]
          end
        end
        send_data(report_csv, :type => "text/csv; charset=utf-8; header=present", :filename => filename)
      end
    end
  end

  def show
    @site_contact = SiteContact.find(params[:id])
    respond_with @site_contact
  end

  def destroy
    @site_contact = SiteContact.find(params[:id])
    @site_contact.destroy
    respond_with @site_contact, :location => admin_site_contacts_path
  end
end
