class Admin::ApplicationController < ApplicationController
  layout "admin"

  before_filter :authenticate_user!

  rescue_from CanCan::AccessDenied do |exception|
    redirect_to admin_root_url
  end
end
