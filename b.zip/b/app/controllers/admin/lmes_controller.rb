class Admin::LmesController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    if ((params[:year].present?)||(params[:month].present?))
      @sql = "1=1"
      if (params[:year].present?)
        @sql += " AND YEAR(quotation_date)='"+params[:year]+"'"
      end
      if (params[:month].present?)   
        @sql += " AND MONTH(quotation_date)='"+params[:month]+"'"
      end
      @lmes = Lme.find(:all, :conditions => @sql)
    else
      @lmes = Lme.all
    end
    respond_with @lmes
  end

  def new
    @lme = Lme.new
    respond_with @lme
  end

  def edit
    @lme = Lme.find(params[:id])
    @lme.aluminum_price = @lme.aluminum_price.to_s.gsub(".",",")
    @lme.dollar_price = @lme.dollar_price.to_s.gsub(".",",")
  end

  def create
    params[:lme][:aluminum_price] = params[:lme][:aluminum_price].gsub(".", "").gsub(",", ".")
    params[:lme][:dollar_price] = params[:lme][:dollar_price].gsub(".", "").gsub(",", ".")

    @lme = Lme.new(params[:lme])

    flash[:notice] = t("successfully_created", :model => Lme.model_name.human) if @lme.save
    respond_with @lme, :location => admin_lmes_path
  end

  def update
    @lme = Lme.find(params[:id])
    params[:lme][:aluminum_price] = params[:lme][:aluminum_price].gsub(".", "").gsub(",", ".")
    params[:lme][:dollar_price] = params[:lme][:dollar_price].gsub(".", "").gsub(",", ".")
    flash[:notice] = t("successfully_updated", :model => Lme.model_name.human) if @lme.update_attributes(params[:lme])
    respond_with @lme, :location => admin_lmes_path
  end

  def destroy
    @lme = Lme.find(params[:id])
    @lme.destroy
    respond_with @lme, :location => admin_lmes_path
  end

  def destroy_selection
    if params[:items_to_delete]
      removed = Lme.delete(params[:items_to_delete])
      flash[:notice] = "#{removed} registro(s) removido(s) com sucesso!"
    else
      flash[:error] = "Nenhum item selecionado!"
    end
    redirect_to :action => :index
  end 
end
