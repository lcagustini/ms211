class Admin::ResumesController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    @resumes = Resume.all

    respond_to do |format|
      format.html
      format.csv do
        filename = "Curriculums - " + I18n.l(Time.now, :format => :short) + ".csv"

        report_csv = FasterCSV.generate(:col_sep => ";") do |csv|
          # header row
          csv << ["Cadastro em", "Nome", "Email", "Cidade", "Estado", "Curriculum"]

          # data rows
          @resumes.each do |resume|
            csv << [I18n.l(resume.created_at), resume.name, resume.email, resume.city, resume.state, resume.resume]
          end
        end
        send_data(report_csv, :type => "text/csv; charset=utf-8; header=present", :filename => filename)
      end
    end
  end

  def show
    @resume = Resume.find(params[:id])
    respond_with @resume
  end

  def destroy
    @resume = Resume.find(params[:id])
    @resume.destroy
    respond_with @resume, :location => admin_resumes_path
  end
end
