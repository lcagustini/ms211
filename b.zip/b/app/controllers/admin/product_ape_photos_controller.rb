class Admin::ProductApePhotosController < Admin::ApplicationController
  before_filter :load_product

  def index
    @product_photos = @product.product_photos
    respond_with @product_photos
  end

  def new
    @product_photo = ProductPhoto.new
    respond_with @product_photo
  end

  def edit
    @product_photo = ProductPhoto.find(params[:id])
  end

  def create
    @product_photo = ProductPhoto.new(params[:product_photo])
    @product_photo.product = @product

    flash[:notice] = t("successfully_created", :model => ProductPhoto.model_name.human) if @product_photo.save
    respond_with @product_photo, :location => admin_products_ape_product_ape_photos_path(@product)
  end

  def update
    @product_photo = ProductPhoto.find(params[:id])
    @product_photo.product = @product

    flash[:notice] = t("successfully_updated", :model => ProductPhoto.model_name.human) if @product_photo.update_attributes(params[:product_photo])
    respond_with @product_photo, :location => admin_products_ape_product_ape_photos_path(@product)
  end

  def destroy
    @product_photo = ProductPhoto.find(params[:id])
    @product_photo.destroy
    respond_with @product_photo, :location => admin_products_ape_product_ape_photos_path(@product)
  end

  def sort
    @product_photos = @product.product_photos.all

    @product_photos.each do |product_photo|
      product_photo.order_to = params['product-photo'].index(product_photo.id.to_s) + 1
      product_photo.save
    end

    render :nothing => true
  end

  protected

  def load_product
    @product = Product.find(params[:products_ape_id])
  end
end
