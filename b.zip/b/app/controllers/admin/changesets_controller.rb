class Admin::ChangesetsController < Admin::ApplicationController
  def index
    @search = Version.where(:whodunnit => params[:user_id]).order("created_at DESC").search(params[:search])
    @versions = @search.all
    @versions = @search.relation
    @versions = @search.paginate(:page => params[:page]) # Who doesn't love will_paginate?

    respond_with @versions
  end
end
