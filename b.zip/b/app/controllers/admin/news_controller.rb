class Admin::NewsController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    if (params["filtro"].present?)
      @news = News.find(:all, :conditions => ["title like ?", "%" + params["filtro"] + "%"])
    else
      @news = News.all
    end
    respond_with @news
  end

  def new
    @news = News.new
    respond_with @news
  end

  def edit
    @news = News.find(params[:id])
  end

  def create
    @news = News.new(params[:news])
    flash[:notice] = t("successfully_created", :model => News.model_name.human) if @news.save
    respond_with @news, :location => admin_news_index_path
  end

  def update
    @news = News.find(params[:id])
    flash[:notice] = t("successfully_updated", :model => News.model_name.human) if @news.update_attributes(params[:news])
    respond_with @news, :location => admin_news_index_path
  end

  def destroy
    @news = News.find(params[:id])
    @news.destroy
    respond_with @news, :location => admin_news_index_path
  end

  def destroy_selection
    if params[:items_to_delete]
      removed = News.delete(params[:items_to_delete])
      flash[:notice] = "#{removed} registro(s) removido(s) com sucesso!"
    else
      flash[:error] = "Nenhum item selecionado!"
    end
    redirect_to :action => :index
  end 

end
