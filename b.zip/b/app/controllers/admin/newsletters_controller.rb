class Admin::NewslettersController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    @newsletters = Newsletter.all
    
    respond_to do |format|
      format.html
      format.csv do
        filename = "Newsletters - " + I18n.l(Time.now, :format => :short) + ".csv"

        report_csv = CSV.generate do |csv|
          # header row
          csv << ["Cadastro em:", "Email"]

          # data rows
          @newsletters.each do |data|
            csv << [I18n.l(data.created_at),data.email]
          end
        end
        send_data(report_csv, :type => "text/csv; charset=utf-8; header=present", :filename => filename)
      end
    end
  end
end
