class Admin::DashboardController < Admin::ApplicationController
  def index
  end
end
