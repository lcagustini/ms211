class Admin::CategoriesApeController < Admin::ApplicationController
  #load_and_authorize_resource :category

  def index
    @categories = Category.ape.roots
    respond_with @categories
  end
  
  def new
    @category = Category.new
    respond_with @category
  end

  def edit
    @category = Category.find(params[:id])
  end

  def create
    @category = Category.new(params[:category])
    @category.category_type = CategoryType::APE

    flash[:notice] = t("successfully_created", :model => Category.model_name.human) if @category.save
    respond_with @category, :location => admin_categories_ape_index_path
  end

  def update
    @category = Category.find(params[:id])
    @category.category_type = CategoryType::APE
    
    flash[:notice] = t("successfully_updated", :model => Category.model_name.human) if @category.update_attributes(params[:category])
    respond_with @category, :location => admin_categories_ape_index_path
  end

  def destroy
    @category = Category.find(params[:id])

    unless @category.leaf?
      @category.self_and_descendants.destroy
    else
      @category.destroy
    end
    
    respond_with @category, :location => admin_categories_ape_index_path
  end
end
