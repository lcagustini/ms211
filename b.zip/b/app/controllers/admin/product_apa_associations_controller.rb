class Admin::ProductApaAssociationsController < Admin::ApplicationController
  before_filter :load_resources

  def index
    @products = []
    @associated_products = []

    @products = Product.filter_by_category Category.find(params[:category]) if params[:category]

    @collection.product_associations.each do |product_association|
      @associated_products << product_association.associated_product 
    end
  end

  def create
    collection = ProductCollection.find(params[:collection_id])
    associated_product = Product.find(params[:associated_product_id])
    checked = (params[:checked] == "true") ? true : false

    if checked
      ProductAssociation.create!(:product_collection => collection, :associated_product => associated_product)
    else
      # TODO Implementar via chamada REST o metodo delete
      product_associations = ProductAssociation.find(:all, :conditions => [ "product_collection_id = ? AND associated_product_id = ?", collection.id, associated_product.id])
      product_associations.each do |product_association|
        product_association.destroy
      end
    end
    
    render :nothing => true
  end
protected
  def load_resources
    @product = Product.find(params[:products_apa_id])
    @collection = ProductCollection.find(params[:product_apa_collection_id])
    @categories_filter = Category.ape.roots
  end
end
