class Admin::PagesController < Admin::ApplicationController
  after_filter :reload_routes, :only => [:create, :update, :destroy]
  
  #load_and_authorize_resource

  def index
    if (params["filtro"].present?)
      @pages = Page.find(:all, :conditions => ["title like ?", "%" + params["filtro"] + "%"])
    else
      @pages = Page.all
    end
    respond_with @pages
  end

  def new
    @page = Page.new
    respond_with @page
  end

  def edit
    @page = Page.find(params[:id])
  end

  def create
    @page = Page.new(params[:page])
    flash[:notice] = t("successfully_created", :model => Page.model_name.human) if @page.save
    respond_with @page, :location => admin_pages_path
  end

  def update
    @page = Page.find(params[:id])
    flash[:notice] = t("successfully_updated", :model => Page.model_name.human) if @page.update_attributes(params[:page])
    respond_with @page, :location => admin_pages_path
  end

  def destroy
    @page = Page.find(params[:id])
    @page.destroy
    respond_with @page, :location => admin_pages_path
  end

  def destroy_selection
    if params[:items_to_delete]
      removed = Page.delete(params[:items_to_delete])
      flash[:notice] = "#{removed} registro(s) removido(s) com sucesso!"
    else
      flash[:error] = "Nenhum item selecionado!"
    end
    redirect_to :action => :index
  end 

private
  def reload_routes
    AlpexSite::Application.reload_routes!
  end
end
