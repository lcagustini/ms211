class Admin::SustainabilitiesController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    if (params["filtro"].present?)
      @sustainabilities = Sustainability.find(:all, :conditions => ["title like ?", "%" + params["filtro"] + "%"])
    else
      @sustainabilities = Sustainability.all
    end
    respond_with @sustainabilities
  end

  def new
    @sustainability = Sustainability.new
    respond_with @sustainability
  end

  def edit
    @sustainability = Sustainability.find(params[:id])
  end

  def create
    @sustainability = Sustainability.new(params[:sustainability])
    flash[:notice] = t("successfully_created", :model => Sustainability.model_name.human) if @sustainability.save
    respond_with @sustainability, :location => admin_sustainabilities_path
  end

  def update
    @sustainability = Sustainability.find(params[:id])
    flash[:notice] = t("successfully_updated", :model => Sustainability.model_name.human) if @sustainability.update_attributes(params[:sustainability])
    respond_with @sustainability, :location => admin_sustainabilities_path
  end

  def destroy
    @sustainability =Sustainability.find(params[:id])
    @sustainability.destroy
    respond_with @sustainability, :location => admin_sustainabilities_path
  end

  def destroy_selection
    if params[:items_to_delete]
      removed = Sustainability.delete(params[:items_to_delete])
      flash[:notice] = "#{removed} registro(s) removido(s) com sucesso!"
    else
      flash[:error] = "Nenhum item selecionado!"
    end
    redirect_to :action => :index
  end 
end
