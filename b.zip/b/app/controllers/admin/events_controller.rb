class Admin::EventsController < Admin::ApplicationController
  #load_and_authorize_resource

  def index
    @sql = "1=1"


    if ((params["filtro"].present?)||(params["event_type"].present?))

      if (params["event_type"].present?)
        @sql += [" AND event_type = " + params["event_type"]].to_s
      end

      if (params["filtro"].present?)
        @sql += [" AND name like " + ("'%" + params["filtro"] + "%'")].to_s
      end

      @events = Event.find(:all, :conditions => @sql)

    else
      @events = Event.all
    end
    respond_with @events
  end

  def new
    @event = Event.new
    respond_with @event
  end

  def edit
    @event = Event.find(params[:id])
  end

  def create
    @event = Event.new(params[:event])
    flash[:notice] = t("successfully_created", :model => Event.model_name.human) if @event.save
    respond_with @event, :location => admin_events_path
  end

  def update
    @event = Event.find(params[:id])
    flash[:notice] = t("successfully_updated", :model => Event.model_name.human) if @event.update_attributes(params[:event])
    respond_with @event, :location => admin_events_path
  end

  def destroy
    @event = Event.find(params[:id])
    @event.destroy
    respond_with @event, :location => admin_events_path
  end

  def destroy_selection
    if params[:items_to_delete]
      removed = Event.delete(params[:items_to_delete])
      flash[:notice] = "#{removed} registro(s) removido(s) com sucesso!"
    else
      flash[:error] = "Nenhum item selecionado!"
    end
    redirect_to :action => :index
  end 

end
