class Admin::ProductApaCollectionsController < Admin::ApplicationController
  before_filter :load_product

  def index
    @product_collections = @product.product_collections
    respond_with @product_collections
  end

  def show
    @product_collection = ProductCollection.find(params[:id])
    respond_with @product_collection
  end

  def new
    @product_collection = ProductCollection.new
    respond_with @product_collection
  end

  def edit
    @product_collection = ProductCollection.find(params[:id])
  end

  def create
    @product_collection = ProductCollection.new(params[:product_collection])
    @product_collection.product = @product

    flash[:notice] = t("successfully_created", :model => ProductCollection.model_name.human) if @product_collection.save
    respond_with @product_collection, :location => admin_products_apa_product_apa_collections_path(@product)
  end

  def update
    @product_collection = ProductCollection.find(params[:id])
    @product_collection.product = @product

    flash[:notice] = t("successfully_updated", :model => ProductCollection.model_name.human) if @product_collection.update_attributes(params[:product_collection])
    respond_with @product_collection, :location => admin_products_apa_product_apa_collections_path(@product)
  end

  def destroy
    @product_collection = ProductCollection.find(params[:id])
    @product_collection.destroy
    respond_with @product_collection, :location => admin_products_apa_product_apa_collections_path(@product)
  end

protected
  def load_product
    @product = []

    @product = Product.find(params[:products_apa_id])
  end
end
