class Admin::UsersController < Admin::ApplicationController
  #load_and_authorize_resource
  after_filter :update_permissions, :only => [:create, :update]

  def index
    @users = User.all
    respond_with @users
  end

  def new
    @user = User.new
    respond_with @user
  end

  def edit
    @user = User.find(params[:id])
  end

  def create
    @user = User.new(params[:user])

    flash[:notice] = t("successfully_created", :model => User.model_name.human) if @user.save

    respond_with @user, :location => admin_users_path
  end

  def update
    @user = User.find(params[:id])

    if params[:user][:password].present?
      flash[:notice] = t("successfully_updated", :model => User.model_name.human) if @user.update_attributes(params[:user])
    else
      flash[:notice] = t("successfully_updated", :model => User.model_name.human) if @user.update_without_password(params[:user])
    end
    
    respond_with @user, :location => admin_users_path
  end

  def destroy
    @user = User.find(params[:id])
    @user.destroy
    respond_with @user, :location => admin_users_path
  end

  private

  def update_permissions
    permissions_to_read    = []
    permissions_to_create  = []
    permissions_to_update  = []
    permissions_to_destroy = []

    permissions_to_read    = params[:permissions_to_read] if params[:permissions_to_read].present?
    permissions_to_create  = params[:permissions_to_create] if params[:permissions_to_create].present?
    permissions_to_update  = params[:permissions_to_update] if params[:permissions_to_update].present?
    permissions_to_destroy = params[:permissions_to_destroy] if params[:permissions_to_destroy].present?

    @user.app_modules.destroy_all
    @user.app_module_ids = (permissions_to_read + permissions_to_create + permissions_to_update + permissions_to_destroy).uniq

    @user.permissions.where(:app_module_id => permissions_to_read).update_all(:can_read => true)
    @user.permissions.where(:app_module_id => permissions_to_create).update_all(:can_create => true)
    @user.permissions.where(:app_module_id => permissions_to_update).update_all(:can_update => true)
    @user.permissions.where(:app_module_id => permissions_to_destroy).update_all(:can_destroy => true)
  end
end
