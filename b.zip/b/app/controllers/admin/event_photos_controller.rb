class Admin::EventPhotosController < Admin::ApplicationController
  before_filter :load_event

  def index
    @event_photos = @event.event_photos.all
    respond_with @event_photos
  end

  def new
    @event_photo = EventPhoto.new
    respond_with @event_photo
  end

  def edit
    @event_photo = EventPhoto.find(params[:id])
  end

  def create
    @event_photo = EventPhoto.new(params[:event_photo])
    @event_photo.event = @event

    flash[:notice] = t("successfully_created", :model => EventPhoto.model_name.human) if @event_photo.save
    respond_with @event_photo, :location => admin_event_event_photos_path
  end

  def update
    @event_photo = EventPhoto.find(params[:id])
    @event_photo.event = @event

    flash[:notice] = t("successfully_updated", :model => EventPhoto.model_name.human) if @event_photo.update_attributes(params[:event_photo])
    respond_with @event_photo, :location => admin_event_event_photos_path
  end

  def destroy
    @event_photo = EventPhoto.find(params[:id])
    @event_photo.destroy
    respond_with @event_photo, :location => admin_event_event_photos_path
  end

  def sort
    @event_photos = @event.event_photos.all

    @event_photos.each do |event_photo|
      event_photo.order_to = params['event-photo'].index(event_photo.id.to_s) + 1
      event_photo.save
    end

    render :nothing => true
  end

protected
  def load_event
    @event = Event.find(params[:event_id])
  end
end
