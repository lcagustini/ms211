class Admin::ProductsApaController < Admin::ApplicationController
  #load_and_authorize_resource :product

  def index
    @categories_filter = Category.apa.roots
    
    @products ||= []

    if params[:filtro].present?
      if params[:category].to_i > 0
        @products = Product.apa.where("code like ?", "%#{params[:filtro]}%").filter_by_category Category.find(params[:category])
      else
        @products = Product.apa.where("code like ?", "%#{params[:filtro]}%")
      end
    else
      @products = Product.apa.filter_by_category Category.find(params[:category]) if params[:category].to_i > 0
    end

    respond_with @products
  end

  def show
    @product = Product.find(params[:id])
    respond_with @product
  end

  def new
    @product = Product.new
    @product.category = Category.find(params[:category]) if params[:category]

    respond_with @product
  end

  def edit
    @product = Product.find(params[:id])
  end

  def create
    @product = Product.new(params[:product])
    @product.product_type = ProductType::APA

    flash[:notice] = t("successfully_created", :model => Product.model_name.human) if @product.save
    respond_with @product, :location => admin_products_apa_index_path(:category => @product.category)
  end

  def update
    @product = Product.find(params[:id])
    @product.product_type = ProductType::APA

    flash[:notice] = t("successfully_updated", :model => Product.model_name.human) if @product.update_attributes(params[:product])
    respond_with @product, :location => admin_products_apa_index_path(:category => @product.category)
  end

  def destroy
    @product = Product.find(params[:id])
    @product.destroy
    respond_with @product, :location => admin_products_apa_index_path(:category => @product.category)
  end

  def destroy_selection
    if params[:items_to_delete]
      removed = Product.delete(params[:items_to_delete])
      flash[:notice] = "#{removed} registro(s) removido(s) com sucesso!"
    else
      flash[:error] = "Nenhum item selecionado!"
    end
    redirect_to :action => :index
  end 

  def sort
    @products ||= []
    @products = Product.filter_by_category Category.find(params[:category]) if params[:category]

    @products.each do |product|
      product.order_to = params[:sort].index(product.id.to_s) + 1
      product.save

      p product
    end

    render :nothing => true
  end
end
