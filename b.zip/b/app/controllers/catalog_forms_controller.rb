# -*- encoding: utf-8 -*-
class CatalogFormsController < ApplicationController
  layout "contact"

  def new
    @meta_title = "Alpex | Solicitação de Catálogo"
    @catalog_form = CatalogForm.new
    respond_with @catalog_form
  end

  def create
    @meta_title = "Alpex | Solicitação de Catálogo"
    @catalog_form = CatalogForm.new(params[:catalog_form])
    
    if @catalog_form.valid? == true
      NotificationMailer.catalog_form(params[:catalog_form]).deliver
      respond_with @catalog_form
    else
      render :new
    end
  end

end
