# -*- encoding: utf-8 -*-
class ApplicationController < ActionController::Base
  protect_from_forgery
  before_filter :load_default_meta_tags
  respond_to :html

protected    
  def load_default_meta_tags
    @meta_description = ""
    @meta_title = ""
    @meta_keywords = ""
    @meta_url = url_for(:only_path => false)
  end

end
