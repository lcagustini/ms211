# -*- encoding: utf-8 -*-
class NewsController < ApplicationController
  layout "pressroom"

  def index
    if params[:tipo].present?
      if params[:tipo]=="u"
        @news = News.order("event_at DESC").paginate(:page => params[:page], :per_page => 5) #adicionado o paginate para não gerar erro na view
      elsif params[:tipo]=="a" # foi feito com else if, pra ter certeza que é uma ou outra opção  / e p = proximos e r = realizados
        @news = News.offset(5).order("event_at DESC").paginate(:page => params[:page], :per_page => 50)
      end
    else
      params[:tipo] = "u" #para vir de cada selecionado utlimas noticias
      @news = News.order("event_at DESC").paginate(:page => params[:page], :per_page => 5) #adicionado o paginate para não gerar erro na view
    end

    @meta_title = "Alpex | Sala de Imprensa - Notícias"

    if params[:tipo] == "a"
      @archived_news = true
    else
      @archived_news = false
    end
    respond_with @news
  end

  def show
    @news = News.find(params[:id])

    @meta_title = "Alpex | #{@news.title} - #{@news.subtitle}"
    @meta_description = @news.content

    respond_with @news
  end
end
