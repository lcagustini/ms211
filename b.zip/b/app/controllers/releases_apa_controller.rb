# -*- encoding: utf-8 -*-
class ReleasesApaController < ApplicationController
  layout "release"

  def index
    @meta_title = "Alpex - Lançamentos Acabados"

    @products = Product.releases.active.apa.paginate :page => params[:page]
  end
end
