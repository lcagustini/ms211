# -*- encoding: utf-8 -*-
require 'will_paginate/array'
class SearchController < ApplicationController
  layout "search"
  def index
    @search           = SearchAdapter.new(params[:busca])
    @total_of_results = @search.total_of_results 
    @results          = @search.results.paginate :page => params[:page], :per_page => 10
    @meta_title       = "Alpex | Busca"
  end
end
