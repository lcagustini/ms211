# -*- encoding: utf-8 -*-
class LmesController < ApplicationController

  layout "about"
  before_filter :load_quotations_sidebar

  def index
    @meta_title = "Alpex | Cotações LME"
    @meta_description = "Os valores da LME referem-se à média entre o CASH BUYER e CASH SELLER & SETTLEMENT."
    @meta_keywords = "alpex, alumínio, cotaçõs, lme, dollar"

    @lme_last = Lme.order("quotation_date DESC").first
    @lmes_graph_subtitle = ""

    if params[:f].present?

      if params[:f]=="sa"

        @lmes_graph  = Lme.quotations_graph_weekly(params[:month], params[:year]).reorder("quotation_date DESC").limit(5)

        @lmes_graph.each do |lmes_graph|
          
          if (@lmes_graph_subtitle.present?)
            @lmes_graph_subtitle = "\'" + l(lmes_graph.quotation_date, :format => "%d/%a") + "\', " + @lmes_graph_subtitle
          else
            @lmes_graph_subtitle = "\'" + l(lmes_graph.quotation_date, :format => "%d/%a") + "\'"
          end

        end

      elsif params[:f]=="m"

        @lmes_graph = Lme.quotations_graph_monthly(params[:month], params[:year])
        @lmes_graph.each do |lmes_graph|

          if (@lmes_graph_subtitle.present?)
            @lmes_graph_subtitle = "\'" + lmes_graph.quotation_date.day.to_s + "\', " + @lmes_graph_subtitle
          else
            @lmes_graph_subtitle = "\'" + lmes_graph.quotation_date.day.to_s + "\'"
          end

        end

      elsif params[:f]=="a"

        params[:year] = @lme_last.quotation_date.year
        params[:month] = @lme_last.quotation_date.month

        @lmes_graph_annual = Lme.quotations_graph_annual(params[:month], params[:year])

        @lmes_graph = []

        @lmes_sidebar.keys.reverse.each do |year|
          @lmes_sidebar[year].reverse.each do |month|
            #SQLITE
            #@lmes_graph.push(Lme.average(:aluminum_price, :conditions => ["strftime('%m', quotation_date) = ? AND strftime('%Y', quotation_date) = '?'", '%02d' % month, year]))
            #MySQL
            @lmes_graph.push(Lme.average(:aluminum_price, :conditions => ["MONTH(quotation_date) = ? AND YEAR(quotation_date) = ?", month, year]))
            if (@lmes_graph_subtitle.present?)
              @lmes_graph_subtitle = "\'" + l(Time.parse("#{year}-#{month}-1"), :format => "%b") + "\', " + @lmes_graph_subtitle
            else
              @lmes_graph_subtitle = "\'" + l(Time.parse("#{year}-#{month}-1"), :format => "%b") + "\'"
            end
          end
        end

      end

      @lmes = Lme.quotations_at_month(params[:month], params[:year]).paginate(:page => params[:page])

    else

      if params[:month].present? and params[:year].present?

        @lmes = Lme.quotations_at_month(params[:month], params[:year]).paginate(:page => params[:page])
        @lmes_graph = Lme.quotations_graph_monthly(params[:month], params[:year])

        @lmes_graph.each do |lmes_graph|
          if (@lmes_graph_subtitle.present?)
            @lmes_graph_subtitle = "\'" + lmes_graph.quotation_date.day.to_s + "\', " + @lmes_graph_subtitle
          else
            @lmes_graph_subtitle = "\'" + lmes_graph.quotation_date.day.to_s + "\'"
          end
        end

      else

        # Veja ticket #625
        #@lmes = Lme.quotations_last_month.paginate(:page => params[:page])
        @lmes = Lme.quotations_at_month(@lme_last.quotation_date.month, @lme_last.quotation_date.year).paginate(:page => params[:page])
        @lmes_graph = Lme.quotations_graph_monthly(@lme_last.quotation_date.month, @lme_last.quotation_date.year)
        params[:year] = @lme_last.quotation_date.year
        params[:month] = @lme_last.quotation_date.month

        @lmes_graph.each do |lmes_graph|
          if (@lmes_graph_subtitle.present?)
            @lmes_graph_subtitle = "\'" + lmes_graph.quotation_date.day.to_s + "\', " + @lmes_graph_subtitle
          else
            @lmes_graph_subtitle = "\'" + lmes_graph.quotation_date.day.to_s + "\'"
          end
        end


      end

    end

    @graph_title = ""
    @graph_subtitle = ""

    if !params[:f].present?
      params[:f] = "m"
    end

    respond_with @lmes
  end

private
  def load_quotations_sidebar
    @lmes_sidebar = {}

    Lme.last_quotations.reorder("quotation_date").each do |lme|
      
      year = lme.quotation_date.strftime("%Y").to_i
      month = lme.quotation_date.strftime("%m").to_i

      @lmes_sidebar[year] ||= []
      @lmes_sidebar[year]<< month if @lmes_sidebar[year].index(month) == nil

    end

  end
end
