# -*- encoding: utf-8 -*-
class SitemapController < ApplicationController
  layout "about"

  def index
    @meta_title = "Alpex | Mapa do Site"
  end
end
