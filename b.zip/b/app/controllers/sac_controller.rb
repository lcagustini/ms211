# -*- encoding: utf-8 -*-
class SacController < ApplicationController
  layout "contact"

  def new
    @meta_title = "Alpex | SAC"
    @contact = SiteContact.new
    respond_with @contact
  end

  def create
    @meta_title = "Alpex | SAC"
    @contact = SiteContact.new(params[:site_contact])
    @contact.contact_type = ContactType::SAC

    if @contact.valid? == true
      @contact.save
      NotificationMailer.sac_form(params[:site_contact]).deliver
      respond_with @saved
    else
      render :new
    end

  end

end
