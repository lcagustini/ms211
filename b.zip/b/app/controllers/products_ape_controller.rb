# -*- encoding: utf-8 -*-
class ProductsApeController < ApplicationController
  layout "product"

  def show
    @product = Product.find(params[:id])
    @category = @product.category
    
    @meta_title = "Alpex | Produtos Extrudados: " + @product.name
    @meta_description = @product.description
    @meta_keywords = @product.meta_keywords
  end

  def set_budget_basket
    session[:ape_products_budget_basket] ||= []
   
    params[:id].split(",").each do |product_slug|
      product = Product.find_by_slug(product_slug)
      session[:ape_products_budget_basket] << product.id
    end

    render :nothing => true
  end

  def set_send_to_friend_basket
    session[:ape_products_send_to_friend_basket] ||= []
 
    params[:id].split(",").each do |product_slug|
      product = Product.find_by_slug(product_slug)
      session[:ape_products_send_to_friend_basket] << product.id
    end

    render :nothing => true
  end
end
