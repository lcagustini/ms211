# -*- encoding: utf-8 -*-
require 'will_paginate/array'

class AdvancedSearchController < ApplicationController
  layout "search"

  def index
    @pages    ||= []
    @news     ||= []
    @products ||= []

    if (params["busca-avancada"] && params["paginas"] == "paginas")
      @sql = "content LIKE ?", "%"+params["busca-avancada"]+"%"
      @pages = Page.where(@sql)
    end

    if (params["busca-avancada"] && params["noticias"] == "noticias")
      @sql = "(content LIKE ?) OR (title LIKE ?)", "%"+params["busca-avancada"]+"%", "%"+params["busca-avancada"]+"%"
      @news = News.where(@sql)
    end

    if (params["busca-avancada"] && params["produtos"] == "produtos")  
      if (params["apa"] == "apa")
        @sql = "(name LIKE ?) OR (description LIKE ?) OR (features LIKE ?)", "%"+params["busca-avancada"]+"%", "%"+params["busca-avancada"]+"%", "%"+params["busca-avancada"]+"%"
      end
      if (params["ape"] == "ape")
        @sql = "(name LIKE ?) OR (description LIKE ?) OR (features LIKE ?) OR (code LIKE ?)", "%"+params["busca-avancada"]+"%", "%"+params["busca-avancada"]+"%", "%"+params["busca-avancada"]+"%", "%"+params["code"]+"%"
      end
      @products = Product.where(@sql)
    end

    @total_of_results = 0
    @total_of_results += @news.size
    @total_of_results += @pages.size
    @total_of_results += @products.size

    @results = @pages + @news + @products
    @results = @results.paginate :page => params[:page], :per_page => 10

    @meta_title = "Alpex | Busca Avançada"

    respond_with @advanced_search
  end
end
