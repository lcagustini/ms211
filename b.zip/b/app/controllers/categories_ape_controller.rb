# -*- encoding: utf-8 -*-
class CategoriesApeController < ApplicationController
  layout "product"

  def index
    @meta_title = "Alpex | Produtos Extrudados - Uma infinidade de soluções em perfis"
    @meta_description = "Uma infinidade de soluções em perfis"
    @meta_keywords = "alpex, produtos, extrudados, soluções, perfis, lançamentos, acabamentos"
  end

  def show
    @category = Category.find(params[:id])
    
    @products = @category.products.ape.active
    @products = @products.reorder("CAST(mm_a AS decimal)") if @category.clustered
    
    @clustered_view = @category.clustered

    @show_column_b = true if @products.where("mm_b is not null and mm_b != '' and inch_b is not null and inch_b != ''").exists?
    @show_column_c = true if @products.where("mm_c is not null and mm_c != '' and inch_c is not null and inch_c != ''").exists?

    render :status => 404 if not @category.present?
    
    @meta_title = "Alpex | Produtos Extrudados: " + @category.name
    @meta_description = @category.description
    @meta_keywords = @category.meta_keywords
  end
end
