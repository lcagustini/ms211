# -*- encoding: utf-8 -*-
class GalleryController < ApplicationController
  layout "no_submenu"

  def index
    @gallery = Event.where("event_at < ?", Date.today).includes(:event_photos).group("event_photos.id").having("count(event_photos.id)>0").order("events.event_at DESC, event_photos.order_to").paginate(:page => params[:page])
    @meta_title = "Alpex | Eventos - Galeria de Eventos"

    respond_with @gallery
  end

  def show
    @gallery = Event.find(params[:id])

    @meta_title = @gallery.name + " - " + l(@gallery.event_at, :format => :long)
    @meta_description = @gallery.name
    @meta_keywords = @gallery.meta_keywords

    respond_with @gallery
  end

end
