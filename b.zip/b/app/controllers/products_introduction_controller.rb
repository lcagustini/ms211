# -*- encoding: utf-8 -*-
class ProductsIntroductionController < ApplicationController
  layout "product"
  def index
    @meta_title = "Alpex | Produtos -  Conheça os Catálogos de Produtos Extrudados e Acabados"
  end
end
