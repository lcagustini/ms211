# -*- encoding: utf-8 -*-
class PagesController < ApplicationController
  before_filter :load_page
  before_filter :set_layout

  def show
    render "pages/#{@page.slug_normalized}/page"
  end

private
  def load_page
    @page = Page.find(params[:id])
    @meta_description = @page.meta_description if @page.meta_description?
    @meta_title = @page.meta_title if @page.meta_title?
    @meta_keywords = @page.meta_keywords if @page.meta_keywords?
  end

  def set_layout
    template = PageTemplate.key_for(@page.template)
    self.class.layout "pages/#{template}"
  end
end
