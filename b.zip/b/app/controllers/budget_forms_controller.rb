# -*- encoding: utf-8 -*-
class BudgetFormsController < ApplicationController
  layout "contact"

  def new
    @budget_form = BudgetForm.new

    @budget_form.message = ""

    if session[:apa_products_budget_basket].present?
      @products = Product.where(:id => session[:apa_products_budget_basket]).reorder("products.name")

      @budget_form.message << "Lista de produtos acabados para orçamento:\n\n"

      @products.each_with_index do |product,index|
        @budget_form.message << "#{index + 1} - Produto: " << product.name << "\n"
      end

      @budget_form.message << "\n\n"
    end

    if session[:ape_products_budget_basket].present?
      @products = Product.where(:id => session[:ape_products_budget_basket]).reorder("products.code")

      @budget_form.message << "Lista de produtos extrudados para orçamento:\n\n"

      @products.each_with_index do |product,index|
        @budget_form.message << "#{index + 1} - Produto código: " << product.code << "\n"
      end
    end

    @meta_title = "Alpex | Orçamentos - Solicite um Orçamento"
  end

  def create
    @meta_title = "Alpex | Orçamentos - Solicite um Orçamento"
    
    @budget_form = BudgetForm.new(params[:budget_form])

    if @budget_form.valid? == true
      NotificationMailer.budget_form(params[:budget_form]).deliver
      session[:ape_products_budget_basket] = nil
      session[:apa_products_budget_basket] = nil
      respond_with @saved
    else
      render :new
    end
  end

end
