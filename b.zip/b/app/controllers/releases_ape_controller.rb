# -*- encoding: utf-8 -*-
class ReleasesApeController < ApplicationController
  layout "release"

  def index
    @meta_title = "Alpex - Lançamentos Extrudados"

    @products = Product.releases.active.ape.paginate :page => params[:page]
  end
end
