# -*- encoding: utf-8 -*-
class CategoriesApaController < ApplicationController
  layout "product"

  def index
    @categories = Category.apa.roots

    @meta_title = "Alpex | Produtos Acabados - Conheça a nossa linha de Produtos Acabados"
    @meta_description = "Conheça a nossa linha de Produtos Acabados"
    @meta_keywords = "alpex, produtos, acabados, kit, box, enganharia, acqua, plus, moveleira, linha"
  end

  def show
    @category = Category.find(params[:id])
    @products = @category.products.apa.active

    render :status => 404 if not @category.present?
    
    @meta_title = "Alpex | Produtos Acabados: " + @category.name
    @meta_description = @category.description
    @meta_keywords = @category.meta_keywords
  end
end
