# -*- encoding: utf-8 -*-
class ResumesController < ApplicationController
  layout "how_to_get"

  def new
    @meta_title = "Alpex | Trabalhe Conosco"
    @resume = Resume.new
    respond_with @resume
  end

  def create
    @meta_title = "Alpex | Trabalhe Conosco"
    @resume = Resume.new(params[:resume])

    if @resume.valid? == true
      @resume.save
      NotificationMailer.resume_form(params[:resume]).deliver
    else
      render :new
    end
  end
end
