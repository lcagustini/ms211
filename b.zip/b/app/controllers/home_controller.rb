# -*- encoding: utf-8 -*-
class HomeController < ApplicationController
  def index
    @meta_title = "Alpex | Sua solução em Alumínio"
    @meta_description = "Alpex Alumínio atua no desenvolvimento de soluções em perfis extrudados de alumínio e de projetos especiais, feitos sob medida."
    @meta_keywords = "alpex, alumínio, extrudados, acabados, moveleira, kit-box, esquadrias, trilho, divisórias, kit-engenharia, puxadores, prateleiras, calceiros, acessórios e arremates"
    @lme = Lme.order("quotation_date DESC").first
  end
end
