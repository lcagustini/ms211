# -*- encoding: utf-8 -*-
class SustainabilityActionsController < ApplicationController
  layout "about"

  before_filter :load_sustainability_list_for_sidebar

  def index
    @sustainability_actions = Sustainability.paginate :page => params[:page], :per_page => 10
    @meta_title = "Alpex | Ações de Sustentabilidade"
    respond_with @sustainability_actions
  end

  def show
    @sustainability_action = Sustainability.find(params[:id])

    @meta_title = "#{@sustainability_action.title} - #{@sustainability_action.subtitle}"
    @meta_description = @sustainability_action.description


    respond_with @sustainability_action
  end

private
  def load_sustainability_list_for_sidebar
    @sustainability_actions_sidebar = Sustainability.limit(10)
  end
end
