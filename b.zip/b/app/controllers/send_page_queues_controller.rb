# -*- encoding: utf-8 -*-
class SendPageQueuesController < ApplicationController
  def create
    @send_page_queue = SendPageQueue.new(:session_id=>request.session_options[:id], :url=>params["u"], :title=>params["t"])
    @send_page_queue.save
  end
end
