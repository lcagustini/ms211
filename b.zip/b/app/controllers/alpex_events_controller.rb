# -*- encoding: utf-8 -*-
class AlpexEventsController < ApplicationController
  layout "event"

  def index
    event_type = EventType::ALPEX #Forçado porque nesta tela só pode aparecer do tipo certo, qq duvida ver enumerations "event_type"

    if params[:tipo].present?
      if params[:tipo]=="p"
        @alpex_events = Event.where("event_type = ? AND event_at >= ?", event_type, Date.today).order("event_at ASC").paginate(:page => params[:page], :per_page => 10)
      elsif params[:tipo]=="r"      # foi feito com else if, pra ter certeza que é uma ou outra opção  / e p = proximos e r = realizados
        @alpex_events = Event.where("event_type = ? AND event_at < ?", event_type, Date.today).order("event_at DESC").paginate(:page => params[:page], :per_page => 10)
      end
    else

      params[:tipo] = "p" #para vir de cada seleciona os próximos
      @alpex_events = Event.where("event_type = ? AND ( (event_at >= ?) OR (event_at <= ? AND event_end_at >= ?) )", event_type, Date.today, Date.today, Date.today).order("event_at ASC").paginate(:page => params[:page], :per_page => 10)
    end

    @meta_title = "Alpex | Eventos - Agenda da Alpex"

    respond_with @alpex_events
  end
end
