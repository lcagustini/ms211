# -*- encoding: utf-8 -*-
class ProductsApaController < ApplicationController
  layout "product"

  def show
    @product = Product.active.find(params[:id])
    @category = @product.category
    
    @collections = @product.product_collections

    @meta_title = "Alpex | Produtos Acabados: " + @product.name
    @meta_description = @product.description
    @meta_keywords = @product.meta_keywords
  end

  def set_budget_basket
    session[:apa_products_budget_basket] ||= []
 
    params[:id].split(",").each do |product_slug|
      product = Product.find_by_slug(product_slug)
      session[:apa_products_budget_basket] << product.id
    end

    render :nothing => true
  end

  def set_send_to_friend_basket
    session[:apa_products_send_to_friend_basket] ||= []
 
    params[:id].split(",").each do |product_slug|
      product = Product.find_by_slug(product_slug)
      session[:apa_products_send_to_friend_basket] << product.id
    end

    render :nothing => true
  end
end
