# -*- encoding: utf-8 -*-
class NewsletterController < ApplicationController
  layout "no_submenu"

  def create
    @meta_title = "Alpex | Newsletter"

    @newsletter = Newsletter.new
    @newsletter.email = params[:email]
    @newsletter.newsletter_type = params[:tipo]
    @newsletter.save

    respond_with @newsletter, :location => new_contact_path
  end
end
