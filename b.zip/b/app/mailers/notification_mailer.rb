# -*- encoding: utf-8 -*-
class NotificationMailer < ActionMailer::Base
  default :from => SITE_CONFIG['email_notification']['default_sender'],
          :reply_to => SITE_CONFIG['email_notification']['default_reply_to']

  def contact_form(form_vars)
    @form_vars = form_vars

    @email_to = SITE_CONFIG['email_notification']['destination']['contact_form'][ContactDepartment.key_for(@form_vars[:department_sent].to_i).to_s]
    @title = "Alpex - Contato do site"

    # Ajustando os valores do enumerate. Isso deve ser feito depois do email_to (acima)
    @form_vars[:department_sent] = ContactDepartment.t(@form_vars[:department_sent].to_i)

    mail(:to => @email_to, :subject => @title)
  end

  def sac_form(form_vars)
    @form_vars = form_vars
    
    @email_to = SITE_CONFIG['email_notification']['destination']['sac_form'][AlpexUnit.key_for(@form_vars[:unit].to_i).to_s]
		
    # Ajustando os valores do enumerate. Isso deve ser feito depois do email_to (acima)
    @form_vars[:unit] = AlpexUnit.t(@form_vars[:unit].to_i)

    @title = "Alpex - SAC"
    mail(:to => @email_to, :subject => @title)
  end

  def resume_form(form_vars)
    @form_vars = form_vars
    
    @email_to = SITE_CONFIG['email_notification']['destination']['resume_form']
    @title = "Trabalhe Conosco #{@form_vars[:name]} #{@form_vars[:operating_area]}, enviou curriculo pelo site."

    mail(:to => @email_to, :subject => @title)
  end

  def budget_form(form_vars)
    @form_vars = form_vars

    @email_to = SITE_CONFIG['email_notification']['destination']['budget_form'][AlpexUnit.key_for(@form_vars[:unit].to_i).to_s]

    # Ajustando os valores do enumerate. Isso deve ser feito depois do email_to (acima)
    @form_vars[:unit] = AlpexUnit.t(@form_vars[:unit].to_i)

    @title = "Alpex - Orçamento"
    mail(:to => @email_to, :subject => @title)
  end

  def send_page(form_vars)
    @form_vars = form_vars
    @form_vars.each do|name,value|
      @email_to = value if (name == "Email do Amigo")
    end

    @title = "Indique para um amigo"
    mail(:to => @email_to, :subject => @title) if @email_to.present?
  end

  def catalog_form(form_vars)
    @form_vars = form_vars

    @email_to = SITE_CONFIG['email_notification']['destination']['catalog_form'][AlpexUnit.key_for(@form_vars[:unit].to_i).to_s]
    # Ajustando os valores do enumerate. Isso deve ser feito depois do email_to (acima)
    @form_vars[:unit] = AlpexUnit.t(@form_vars[:unit].to_i)

    @title = "Alpex - Solicitação de Catálogo"
    mail(:to => @email_to, :subject => @title)
  end
end
