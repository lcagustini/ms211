class Permission < ActiveRecord::Base
  belongs_to :user
  belongs_to :app_module

  validates_presence_of :user, :app_module
end
