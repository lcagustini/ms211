class News < ActiveRecord::Base
  before_validation :generate_slug

  validates_presence_of :title, :content, :event_at
  validates_uniqueness_of :slug

  validates_attachment_size :photo, :less_than => 2.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "2 MB")
  validates_attachment_content_type :photo, :content_type => %w(image/png image/jpeg image/pjpeg image/gif), :message => I18n.t("activerecord.errors.messages.attachment.content", 
    :format => "JPEG, PNG, GIF")

  has_attached_file :photo, :styles => {:tiny => "172x130#", :medium => "434x326#"}

  has_paper_trail

  default_scope :order => "event_at DESC"

  def slug_normalized
    self.slug.gsub("-", "_")
  end

protected
  def generate_slug
    self.slug = title.parameterize
  end
end
