# -*- encoding: utf-8 -*-
class Event < ActiveRecord::Base
  has_many :event_photos, :dependent => :destroy

  validates_presence_of :name, :place, :event_at
  validates_associated :event_photos

  validate :event_end_at_date_valid?

  has_enumeration_for :event_type, :with => EventType, :required => true, :create_scopes => true

  has_paper_trail

private
  def event_end_at_date_valid?
    if event_end_at.present?
      if event_end_at < event_at
        errors[:event_end_at] << "deve ser maior que a data de início."
      end
    end
  end
end
