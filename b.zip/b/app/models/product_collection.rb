class ProductCollection < ActiveRecord::Base
  belongs_to :product
  has_many :product_associations, :dependent => :destroy

  validates_presence_of :name, :product
  validates_associated :product_associations

  default_scope :order => "name"

  scope :with_product, lambda { |product| where("product_collections.product_id = ?", product) }
end
