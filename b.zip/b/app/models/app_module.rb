class AppModule < ActiveRecord::Base
  has_many :permissions, :dependent => :destroy

  validates_associated :permissions
  validates_presence_of :name, :subject_class
  validates_uniqueness_of :name

  default_scope :order => "name"
end
