class ProductPhoto < ActiveRecord::Base
  belongs_to :product

  validates_presence_of :product
  validates_attachment_size :photo, :less_than => 2.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "2 MB")
  validates_attachment_content_type :photo, :content_type => %w(image/png image/jpeg image/pjpeg image/gif), :message => I18n.t("activerecord.errors.messages.attachment.content", 
    :format => "JPEG, PNG, GIF")

  has_attached_file :photo, :styles => {
    :color_thumb => "79x62#",

    :application_thumb => "100x95#",

    :model_thumb => "x105",
    
    :ape_thumb => "130x115#",
    :apa_thumb => "278x117#",

    :ape_tiny => "290x322#",
    
    :tiny => "130x115#", 
    :medium => "800x600#"
  }

  has_enumeration_for :photo_type, :with => ProductPhotoType, :required => true, :create_scopes => true

  default_scope :order => "order_to"

  # Admin scopes
  scope :with_photo_type, lambda { |product_photo_type| where(:photo_type => product_photo_type) }
end
