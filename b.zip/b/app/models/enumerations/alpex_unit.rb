class AlpexUnit < EnumerateIt::Base
 associate_values(
   :ape => 2
 )
end
