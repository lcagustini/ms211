class InterestArea < EnumerateIt::Base
 associate_values(
  :purchasing => 1,
  :sales => 0
 )
end
