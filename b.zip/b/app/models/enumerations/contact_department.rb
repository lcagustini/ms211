class ContactDepartment < EnumerateIt::Base
 associate_values(
  :marketing => 3,
  :purchasing => 2,
  :sales => 1
 )
end
