class ProductPhotoType < EnumerateIt::Base
  associate_values(:line => 0, :color => 1, :model => 2, :application => 3, :td => 4, :tech => 5, :tech_detail => 6)  
end
