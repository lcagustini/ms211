class ProductType < EnumerateIt::Base
 associate_values(
   :ape => 0,
   :apa => 1
 )
end
