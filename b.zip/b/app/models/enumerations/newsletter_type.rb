class NewsletterType < EnumerateIt::Base
 associate_values(
  :finished_products => 2,
  :sustainability => 0
 )
end
