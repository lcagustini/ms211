class ContactType < EnumerateIt::Base
 associate_values(:contact => 0, :sac => 1)
end
