class PageTemplate < EnumerateIt::Base
  associate_values(
    :sustainability => 4,
    :how_to_get => 3,
    :contact => 2,
    :pressroom => 1,
    :about => 0
  )  
end
