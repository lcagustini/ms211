class EventType < EnumerateIt::Base
 associate_values(:sector => 0, :alpex => 1)
end
