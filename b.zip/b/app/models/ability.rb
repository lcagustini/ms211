class Ability
  include CanCan::Ability

  def initialize(user)
    user ||= User.new

    user.permissions.each do |permission|
      begin
        condition = {}
        # FIXME eval is evil
        condition = eval(permission.app_module.subject_condition) if permission.app_module.subject_condition.present?
        
        mode = []
        mode << :read if permission.can_read
        mode << :create if permission.can_create
        mode << :update if permission.can_update
        mode << :destroy if permission.can_destroy

        can mode, permission.app_module.subject_class.constantize, condition if mode.size > 0
      rescue
        Rails.logger.error "Error on evaluating: #{permission}"
      end
    end
  end
end
