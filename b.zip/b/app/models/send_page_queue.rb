class SendPageQueue < ActiveRecord::Base
end
