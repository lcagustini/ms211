class Product < ActiveRecord::Base
  before_validation :generate_slug
  before_validation :generate_meta_keywords
  before_destroy :destroy_associations

  belongs_to :category
  has_many :product_photos, :dependent => :destroy
  has_many :product_collections, :dependent => :destroy

  validates_presence_of :name, :code, :category
  validates_associated :product_photos
  validates_associated :product_collections
  #validate :release_date_valid?

  validates_attachment_size :banner, :less_than => 1.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "1 MB")
  validates_attachment_content_type :banner, :content_type => ["application/x-shockwave-flash", "image/jpeg", "image/gif", "image/png"], :message => I18n.t("activerecord.errors.messages.attachment.content")


  has_attached_file :banner

  has_enumeration_for :product_type, :with => ProductType, :required => true, :create_scopes => true
  has_enumeration_for :status, :with => ProductStatus, :required => true, :create_scopes => true

  has_paper_trail

  default_scope :order => "products.order_to, products.name"

  # Public scopes
  scope :not_include, lambda { |products| where("products.id NOT IN(?)", products) }
  scope :releases, lambda { where("products.release_date > ?", Time.now.midnight) }

  # Admin scopes
  scope :filter_by_category, lambda { |category| where("products.category_id = ?", category.id) }

  # Custom fields
  def vendor_code
    vendor_code = []

    vendor_code << self.alcan
    vendor_code << self.alcoa
    vendor_code << self.asa

    vendor_code.join " / "
  end

  # Slug methods
  def slug_normalized
    self.slug.gsub("-", "_")
  end

  def to_param
    "#{id}-#{slug}"
  end

protected
  def generate_slug
    self.slug = name.parameterize
  end

  def generate_meta_keywords
    self.meta_keywords = code if not meta_keywords.present? and product_type == ProductType::APE
  end

  def destroy_associations
    product_association = ProductAssociation.where("associated_product_id = ?", self.id)
    product_association.destroy_all
  end

  #def release_date_valid?
  #  if release_date.present?
  #    if release_date.to_time.midnight < Time.now.midnight
  #      errors[:release_date] << "deve ser maior que hoje."
  #    end
  #  end
  #end
end
