class User < ActiveRecord::Base
  has_many :permissions, :dependent => :destroy
  has_many :app_modules, :through => :permissions

  validates_associated :permissions

  # Include default devise modules. Others available are:
  # :token_authenticatable, :encryptable, :confirmable, :lockable, :timeoutable, :registerable and :omniauthable
  devise :database_authenticatable, :recoverable, :rememberable, :trackable, :validatable

  # Setup accessible (or protected) attributes for your model
  attr_accessible :email, :password, :password_confirmation, :remember_me, :app_module_ids

  has_paper_trail

  default_scope :order => "email"
end
