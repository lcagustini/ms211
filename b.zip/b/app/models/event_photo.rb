class EventPhoto < ActiveRecord::Base
  after_initialize :default_values

  belongs_to :event

  validates_presence_of :title, :event

  validates_attachment_size :photo, :less_than => 2.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "2 MB")
  validates_attachment_content_type :photo, :content_type => %w(image/png image/jpeg image/pjpeg image/gif), :message => I18n.t("activerecord.errors.messages.attachment.content", 
  :format => "JPEG, PNG, GIF")

  has_attached_file :photo, :styles => {:tiny => "100x100#", :medium => "800x600#"}

  default_scope :order => "order_to, title"

private
  def default_values
    self.order_to ||= 0
  end
end
