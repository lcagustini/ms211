class Resume < ActiveRecord::Base
  validates_presence_of :name, :email, :operating_area, :phone, :resume
  validates_format_of :email, :with => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\Z/i

  default_scope :order => "created_at DESC"
end
