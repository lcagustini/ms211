class Lme < ActiveRecord::Base
  validates_presence_of :dollar_price, :aluminum_price, :quotation_date
  validates_uniqueness_of :quotation_date

  default_scope :order => "quotation_date DESC"

  has_paper_trail

  scope :quotations_at_month, lambda { |month, year| where("quotation_date BETWEEN ? AND ?", Date.parse("#{year}-#{month}-1"), Date.civil("#{year}".to_i, "#{month}".to_i, -1) )}

  scope :quotations_last_month, lambda { where("quotation_date BETWEEN ? AND ?", Time.now.midnight.beginning_of_month - 1.month, Time.now.midnight.end_of_month - 1.month)}

  scope :last_quotations, lambda { where("quotation_date BETWEEN ? AND ?", Time.now - 1.year, Time.now) }


  scope :quotations_graph_weekly, lambda { |month, year| where("aluminum_holiday='f' AND quotation_date BETWEEN ? AND ?", DateTime.civil("#{year}".to_i,"#{month}".to_i,1,0,0,0), DateTime.civil("#{year}".to_i, "#{month}".to_i, -1,23, 59, 59) )} 

  scope :quotations_graph_biweekly, lambda { |month, year| where("quotation_date BETWEEN ? AND ?", Date.parse("#{year}-#{month}-1"), Date.civil("#{year}".to_i, "#{month}".to_i, -1) )} 

  scope :quotations_graph_monthly, lambda { |month, year| where("aluminum_holiday='f' AND quotation_date BETWEEN ? AND ?", Date.parse("#{year}-#{month}-1"), DateTime.civil("#{year}".to_i, "#{month}".to_i, -1,23, 59, 59) )} 

  scope :quotations_graph_semiannual, lambda { |month, year| where("quotation_date BETWEEN ? AND ?", Date.parse("#{year}-#{month}-1"), Date.civil("#{year}".to_i, "#{month}".to_i, -1) )} 

  scope :quotations_graph_annual, lambda { |month, year| where("quotation_date BETWEEN ? AND ?", Date.parse("#{year}-#{month}-1"), Date.civil("#{year}".to_i, "#{month}".to_i, -1) )} 


  scope :quotations_weekly, lambda { |month, year| where("quotation_date BETWEEN ? AND ?", Time.local(year, month, 1, 0, 0, 0), Time.local(year, month, 1, 0, 0, 0) + 7.day)} 

  scope :quotations_biweekly, lambda { |month, year|  where("quotation_date BETWEEN ? AND ?", Time.local(year, month, 1, 0, 0, 0), Time.local(year, month, 1, 0, 0, 0) + 15.day)} 

  scope :quotations_monthly, lambda { where("quotation_date BETWEEN ? AND ?", Time.now - 1.month, Time.now)} 

  scope :quotations_semiannual, lambda { where("quotation_date BETWEEN ? AND ?", Time.now - 6.month, Time.now)} 

  scope :quotations_annual, lambda { where("quotation_date BETWEEN ? AND ?", Time.now - 1.year, Time.now)} 

end
