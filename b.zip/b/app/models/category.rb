class Category < ActiveRecord::Base
  acts_as_nested_set
  
  attr_protected :lft, :rgt, :depth
  
  before_validation :generate_slug

  has_many :products

  validates_presence_of :name, :description
  validates_associated :products

  validates_attachment_size :clustered_image, :less_than => 1.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "1 MB")
  validates_attachment_content_type :clustered_image, :content_type => %w(image/png image/jpeg image/pjpeg image/gif), :message => I18n.t("activerecord.errors.messages.attachment.content", :format => "JPEG, PNG, GIF")

  validates_attachment_size :image, :less_than => 1.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "1 MB")
  validates_attachment_content_type :image, :content_type => %w(image/png image/jpeg image/pjpeg image/gif), :message => I18n.t("activerecord.errors.messages.attachment.content", :format => "JPEG, PNG, GIF")

  validates_attachment_size :banner, :less_than => 1.megabyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "1 MB")
  validates_attachment_content_type :banner, :content_type => %w(application/x-shockwave-flash), :message => I18n.t("activerecord.errors.messages.attachment.content", :format => "SWF")

  has_attached_file :image, :styles => {:apa_thumb => "278x117#"}
  has_attached_file :banner
  has_attached_file :clustered_image

  has_enumeration_for :status, :with => CategoryStatus, :required => true, :create_scopes => true
  has_enumeration_for :category_type, :with => CategoryType, :required => true, :create_scopes => true

  has_paper_trail

  default_scope :order => "categories.name"

  def slug_normalized
    self.slug.gsub("-", "_")
  end

  def to_param
    "#{id}-#{slug}"
  end

  def self.recursive_path_for(categories, &block)
    categories.each do |category|
      yield category, category.level
      self.recursive_path_for(category.children, &block) unless category.leaf?
    end
  end

protected
  def generate_slug
    #Existem categorias de 4 nivel com mesmo nome tive que mudar o slug
    self.slug = id.to_s + "-" + name.parameterize
  end
end


