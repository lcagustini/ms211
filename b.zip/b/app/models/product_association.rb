class ProductAssociation < ActiveRecord::Base
  belongs_to :product_collection
  belongs_to :associated_product, :class_name => "Product"

  validates_presence_of :product_collection, :associated_product
end
