class BudgetForm

  include ActiveModel::Validations
  include ActiveModel::Conversion
  extend ActiveModel::Naming

  attr_accessor :unit, :business, :branch, :name, :address, :number, :complement, :neighborhood, :zipcode, :city, :state, :phone, :email, :site, :message

  validates :unit, :business, :branch, :name, :address, :number, :neighborhood, :zipcode, :city, :state, :phone, :email, :site, :message, :presence => true
  validates :email, :format => { :with => %r{.+@.+\..+} }, :allow_blank => true
  
  def initialize(attributes = {})
    attributes.each do |name, value|
      send("#{name}=", value)
    end
  end

  def persisted?
    false
  end

end
