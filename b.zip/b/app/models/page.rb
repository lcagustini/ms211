class Page < ActiveRecord::Base
  validates_presence_of :title, :content
  validates_uniqueness_of :slug

  has_enumeration_for :template, :with => PageTemplate, :required => true

  has_paper_trail

  before_validation :generate_slug
  
  default_scope :order => "title DESC"

  def slug_normalized
    self.slug.gsub("-", "_")
  end

protected
  def generate_slug
    if self.slug.present?
      self.slug = title.parameterize if self.slug.empty?
    else
      self.slug = title.parameterize
    end
  end
end
