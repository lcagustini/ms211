class Newsletter < ActiveRecord::Base
  validates_presence_of :email
  validates_format_of :email, :with => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\Z/i

  has_enumeration_for :newsletter_type, :with => NewsletterType, :required => true

  default_scope :order => "email"
end
