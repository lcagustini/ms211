class Sustainability < ActiveRecord::Base
  validates_presence_of :title, :description, :logo

  validates_attachment_size :logo, :less_than => 500.kilobyte, :message => I18n.t("activerecord.errors.messages.attachment.size", :max => "500 KB")
  validates_attachment_content_type :logo, :content_type => %w(image/png image/jpeg image/pjpeg image/gif), :message => I18n.t("activerecord.errors.messages.attachment.content", 
  :format => "JPEG, PNG, GIF")

  has_attached_file :logo, :styles => {:tiny => "172x130#", :medium => "434x326#"}

  has_paper_trail

  default_scope :order => "created_at DESC"
end
