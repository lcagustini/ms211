class DiffService
  include HTMLDiff
end
