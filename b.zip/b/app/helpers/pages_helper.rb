module PagesHelper
  def render_for(page, partial)
    render "pages/#{page.slug_normalized}/#{partial}"
  end
end
