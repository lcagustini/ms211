module TranslationHelper
  # Translate a model attribute from config/locales/models-*.yml for more details.
  #
  # <%= ta Post, :title %>
  #
  def translate_model_attribute(model, attribute)
    model.human_attribute_name(attribute)
  end  
  alias_method :ta, :translate_model_attribute
end
