module CrudHelper
  # Link to new action
  #
  # <%= link_to_new Post, new_post_path %>
  #
  def link_to_new(model, url, html_options = {})
    html_options.reverse_merge!(:class => "new")
    link_to t("new", :model => model.model_name.human), url, html_options
  end

  # Link to back
  #
  # <%= link_to_back Post, posts_path %>
  #
  def link_to_back(model, url, html_options = {})
    html_options.reverse_merge!(:class => "back")
    link_to t("back", :model => model.model_name.human), url, html_options
  end

  # Link to edit action
  #
  # <%= link_to_edit post_path(post) %>
  #
  def link_to_edit(url, html_options = {})
    html_options.reverse_merge!(:class => "edit")
    link_to t("edit"), url, html_options
  end

  # Link to show action
  #
  # <%= link_to_show post_path(post) %>
  #
  def link_to_show(url, html_options = {})
    html_options.reverse_merge!(:class => "show")
    link_to t("show"), url, html_options
  end

  # Link to associate task. e.g: Associated news or pages
  #
  # <%= link_to_associate Page, associated_posts_path  %>
  #
  def link_to_associate(model, url, html_options = {})
    html_options.reverse_merge!(:class => "associate")
    link_to t("associate", :model => model.model_name.human), url, html_options
  end

  # Link to permission task. e.g: User's permission
  #
  # <%= link_to_permission post_permissions_path %>
  #
  def link_to_permission(url, html_options = {})
    html_options.reverse_merge!(:class => "permission")
    link_to t("permission"), url, html_options
  end

  # Link to destroy action
  #
  # <%= link_to_destroy post_path(post) %>
  #
  def link_to_destroy(url, html_options = {})
    html_options.reverse_merge!(:confirm => t('confirm'), :method => :delete, :class => "destroy")
    link_to t("destroy"), url, html_options
  end
end
