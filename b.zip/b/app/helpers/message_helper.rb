module MessageHelper
  # Display errors messages using error_messages partial
  def error_messages_for(resource)
    render 'shared/error_messages', :resource => resource
  end

  # Flash messages from flash[]
  def flash_messages
    flash.collect do |key, msg|
      content_tag(:div, msg, :id => key, :class => "flash-message")
    end.join.html_safe if flash[:alert].present? and not flash[:alert].empty?
  end

  # Display the empty text when collection doesn't present.
  def display_when_present(collection, &block)
    collection.present? ? capture(&block) : I18n.t("empty")
  end
end
