# -*- encoding: utf-8 -*-
module ProductsHelper
  def default_apa_category
    category = Category.find_by_name("Linha Moveleira")

    unless category.present?
      category = Category.roots.first
    end

    category
  end
  
  def ape_breadcrumb(active_category, active_product)
    content_tag :ul, :class => "breadcrumb" do
      items = ""
      items << content_tag(:li, link_to("Produtos", products_introduction_index_path), :class => "first")
      items << content_tag(:li, link_to("Extrudados", categories_ape_index_path), :class => ("last" unless active_category))

      if active_category.present?
        active_category.self_and_ancestors.each do |category|

          has_products = (category.products.count > 0) ? true : false

          category_path = (category.leaf? or has_products) ? categories_ape_path(category) : "javascript:;"

          items << content_tag(:li, link_to(category.name, category_path), :class => ("last" if category == active_category and not active_category.present?))
        end
      end

      if active_product.present?
        items << content_tag(:li, link_to(active_product.name, products_ape_path(active_product)), :class => "last")
      end

      items.html_safe
    end
  end

  def apa_breadcrumb(active_category, active_product)
    content_tag :ul, :class => "breadcrumb" do
      items = ""
      items << content_tag(:li, link_to("Produtos", products_introduction_index_path), :class => "first")
      items << content_tag(:li, link_to("Acabados", categories_apa_path(default_apa_category)), :class => ("last" unless active_category))

      if active_category.present?
        active_category.self_and_ancestors.each do |category|
          category_path = (category.leaf?) ? categories_apa_path(category) : "javascript:;"

          items << content_tag(:li, link_to(category.name, category_path), :class => ("last" if category == active_category and not active_category.present?))
        end
      end

      if active_product.present?
        items << content_tag(:li, link_to(active_product.name, products_apa_path(active_product)), :class => "last")
      end
     
      items.html_safe
    end

  end

  def ape_categories_navigation(active_category)
    ape_categories_navigation_for Category.active.ape.roots, 1, active_category
  end

  def ape_categories_start_navigation
    html = ""

    Category.active.ape.roots.each do |category|
      html << "<div class=\"start-navigation\">"
      html << "<h6>#{category.name}</h6>"
      html << ape_categories_navigation_for(category.children, 0, nil, false)
      html << "</div>"
    end

    html.html_safe
  end

  def apa_categories_navigation(active_category, active_product)
    apa_categories_navigation_for Category.active.apa.roots, 0, active_category, active_product
  end

  def apa_submenu(active_product)
    if active_product.color_description.present? or
      active_product.features.present? or
      active_product.accessories.present? or
      active_product.features_table.present? or
      active_product.dimensions_table.present? or
      active_product.glass.present? or
      active_product.sizes_table.present? or
      active_product.product_photos.model.present?

      content_tag :div, :class => "sub-produtos", :id => "submenu" do
        content_tag :ul do
          items = ""

          items << content_tag(:li, link_to("Cores", "#cores", :title => "Cores disponíveis")) if active_product.color_description.present?
          items << content_tag(:li, link_to("Descrição", "#descricao", :title => "Descrição Técnica")) if active_product.features.present?
          items << content_tag(:li, link_to("Acessórios", "#acessorios", :title => "Acessórios")) if active_product.accessories.present?
          items << content_tag(:li, link_to("Características", "#caracteristicas", :title => "Características")) if active_product.features_table.present?
          items << content_tag(:li, link_to("Dimensões", "#dimensoes", :title => "Dimensões")) if active_product.dimensions_table.present?
          items << content_tag(:li, link_to("Vidro", "#vidro", :title => "Vidro")) if active_product.glass.present?
          items << content_tag(:li, link_to("Tamanhos", "#tamanhos", :title => "Tamanhos")) if active_product.sizes_table.present?
          items << content_tag(:li, link_to("Modelos", "#modelos", :title => "Modelos Disponíveis")) if active_product.product_photos.model.present?

          items.html_safe
        end
      end
    else
      "<div id=\"haste\"></div>".html_safe
    end
  end

private
  def ape_categories_navigation_for(categories, depth, active_category, autohide = true)
    html = ""
    
    hide_style = ""
    
    if depth > 0 and autohide
      if active_category.present?
        hide_style = "display: none;" if (categories & active_category.self_and_ancestors).size == 0
      else
        hide_style = "display: none;"
      end
    end

    html << "<ul class=\"level-#{depth}\" style=\"#{hide_style}\">"

    categories.each do |current_category|
      html << "<li class=\"level-#{depth}\">"

      has_products = (current_category.products.count > 0) ? true : false
      
      category_path = (current_category.leaf? or has_products) ? categories_ape_path(current_category) : "javascript:;"

      can_autohide = (has_products) ? false : autohide
     
      link_class = []
      link_class << "expand" unless current_category.leaf?
      link_class << "ativo" if active_category.present? and active_category.is_or_is_descendant_of?(current_category)
      html << link_to(current_category.name, category_path, :title => current_category.name, :class => link_class.join(" "))
     
      html << ape_categories_navigation_for(current_category.children, current_category.depth + 1, active_category, can_autohide) unless current_category.leaf?

      html << "</li>"
    end

    html << "</ul>"
    html.html_safe
  end

  def apa_categories_navigation_for(categories, depth, active_category, active_product)
    html = ""

    html << "<ul class=\"level-#{depth}\">"

    categories.each do |current_category|
      html << "<li class=\"level-#{depth}\">"

      category_path = (current_category.leaf?) ? categories_apa_path(current_category) : "#"
      html << link_to(current_category.name, category_path, :title => current_category.name, :class => ("ativo" if active_category.present? and active_category.is_or_is_descendant_of?(current_category)))
     
      if current_category.products.count > 0
        html << "<ul class=\"level-#{depth + 1} products-level-#{depth + 1}\">"
        
        current_category.products.each do |current_product|
          html << "<li>"
          html << link_to(current_product.name, products_apa_path(current_product), :title => current_product.name, :class => ("ativo" if active_product.present? and active_product == current_product))
          
          html << apa_categories_navigation_for(current_category.children, current_category.depth + 2, active_category, active_product) if current_category.products.last == current_product
          
          html << "</li>"
        end

        html << "</ul>"
      else
        html << apa_categories_navigation_for(current_category.children, current_category.depth + 1, active_category, active_product) unless current_category.leaf?
      end

      html << "</li>"
    end

    html << "</ul>"
    html.html_safe
  end
end
