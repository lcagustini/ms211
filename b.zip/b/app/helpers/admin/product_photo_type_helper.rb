module Admin::ProductPhotoTypeHelper
	def product_photo_type_permission_to(permission_type)
		photo_type_allowed = []

		ProductPhotoType.to_a.each do |product_photo_type_humanize, product_photo_type|
			photo_type_allowed << [product_photo_type_humanize, product_photo_type] if can? permission_type, ProductPhoto.new(:photo_type => product_photo_type)
		end

		photo_type_allowed
	end
end
