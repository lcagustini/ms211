module Admin::ProductsHelper
  def categories_treeview_filter_for(categories)
    html = ""

    categories.each do |current_category|
      html << "<li>"

      unless current_category.leaf?
        html << "<span class=\"folder\">#{current_category.name}</span>"
        html << "<ul>" << categories_treeview_filter_for(current_category.children) << "</ul>"
      else
        products_count = current_category.products.count
        html << '<span class="file">' << link_to("#{current_category.name} (#{products_count})", url_for(:category => current_category)) << '</span>'
      end
      
      html << "</li>"
    end

    html.html_safe
  end
end
