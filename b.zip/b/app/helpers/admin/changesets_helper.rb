require "diff_service"

module Admin::ChangesetsHelper
  # Ref: https://github.com/igal/paper_trail_manager/blob/master/app/helpers/paper_trail_manager/changes_helper.rb
  def format_diff(version)
    changes = {}
    current = version.next.try(:reify)
    # FIXME #reify randomly throws "ArgumentError Exception: syntax error on line 13, col 30:" -- why?
    previous = version.reify rescue nil
    record = \
      begin
        version.item_type.constantize.find(version.item_id)
      rescue ActiveRecord::RecordNotFound
        previous || current
      end

    # Bail out if no changes are available
    return changes unless record

    case version.event
    when "create", "update"
      current ||= record
    when "destroy"
      previous ||= record
    else
      raise ArgumentError, "Unknown event: #{version.event}"
    end

    (current or previous).attribute_names.each do |name|
      next if name == "updated_at"
      next if name == "created_at"
      current_value = current.read_attribute(name) if current
      previous_value = previous.read_attribute(name) if previous
      unless current_value == previous_value || (version.event == "create" && current_value.blank?)
        changes[name] = {
          :previous => previous_value,
          :current => current_value,
        }
      end
    end

    model = eval(version.item_type)

    diff_service = DiffService.new

    output = ""

    changes.each do |field, changes|

      if changes[:previous].kind_of? DateTime or changes[:previous].kind_of? Date or changes[:previous].kind_of? Time
        date1 = (changes[:previous].present?) ? l(changes[:previous]) : ""
        date2 = (changes[:current].present?) ? l(changes[:current]) : ""

        output << "<li><strong>#{ta(model, field)}:</strong> " + diff_service.diff(date1, date2) + "</li>"
      elsif changes[:previous].kind_of? Fixnum
        output << "<li><strong>#{ta(model, field)}:</strong> " + diff_service.diff(changes[:previous].to_s, changes[:current].to_s) + "</li>"
      else
        output << "<li><strong>#{ta(model, field)}:</strong> " + diff_service.diff(changes[:previous].to_s, changes[:current].to_s) + "</li>"
      end
    end

    output.html_safe
  end
end
