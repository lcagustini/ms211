module BannerHelper
    def render_product_banner_for(active_product, banner_area)
        if active_product.present? and active_product.banner.present?
            render_flash_banner_for active_product.banner.url, active_product.banner_height
        else
            if banner_area=="ape"
                render_flash_banner_for asset_path("categorias-#{banner_area}.swf"), 260
            else
                render_flash_banner_for asset_path("produtos-#{banner_area}.swf"), 480
            end
        end
    end

    def render_category_banner_for(active_category, banner_area)
        if active_category.present? and active_category.banner.present?
            render_flash_banner_for active_category.banner.url, active_category.banner_height
        else

            if banner_area == "ape"
                banner_height = 260
            else
                banner_height = 480
            end

            render_flash_banner_for asset_path("categorias-#{banner_area}.swf"), banner_height
        end
    end

    private
    def render_flash_banner_for(filename, height)
        puts filename
        if filename =~ /\.swf/
            html = ""
            html << "<div id=\"image\" class=\"produto\" style=\"height: #{height}px;\">"
            html << "<object width=\"100%\" height=\"#{height}\" type=\"application/x-shockwave-flash\" data=\"#{filename}\">"
            html << "<param name=\"movie\" value=\"#{filename}\">"
            html << "<param name=\"wmode\" value=\"transparent\">"
            html << "<param name=\"allowFullScreen\" value=\"false\">"
            html << "</object>"
            html << "</div><!-- /image -->"

        else
            html =""
            html << "<div id=\"image\" class=\"produto \" >"
            html << "<img class=\"banner-image\" src=\"#{filename}\" />"
            html << "</div>"
        end
        html.html_safe
    end
end
