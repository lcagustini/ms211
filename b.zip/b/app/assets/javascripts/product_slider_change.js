$(function() {
  $(".slider .opcoes a.change").click(function() {
    item_number = $(this).data("item-number");

    image_3d = $("li#item" + item_number).find("img.3d");
    image_2d = $("li#item" + item_number).find("img.2d");

    if (image_3d.is(":visible")) {
      image_3d.fadeOut("fast");
      image_2d.fadeIn("fast");
      $('.lupa3d').hide();
      $('.lupa2d').show();
    }
    else {
      image_3d.fadeIn("fast");
      image_2d.fadeOut("fast");
      $('.lupa3d').show();
      $('.lupa2d').hide();
    }
  });
});
