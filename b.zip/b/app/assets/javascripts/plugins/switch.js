$(document).ready(function(){
	$('#produto1 a.change').click(function(){ 
		$("#produto1 .slice").animate({"left": "-140px"}, "fast");
	},function(){
		$("#produto1 .slice").animate({"left": "0"}, "fast");
	});
});
