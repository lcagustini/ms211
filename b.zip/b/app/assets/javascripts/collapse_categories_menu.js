$(function () {
    'use strict';
    $("#page #categories .produtos a.expand").click(function (event) {
        $(this).parent().children("ul").each(function (index, el) {
            $(el).fadeToggle("slow");
        });
    });
});

$(function () {
    'use strict';
    $("#CategoriasIndex a.expand").click(function (event) {
        $(this).parent().children("ul").each(function (index, el) {
            $(el).fadeToggle("slow");
        });
    });
});
