$(function () {
    'use strict';
    $(".product-associations-toggle").change(function () {
        collection = $(this).data("collection");
        associated_product = $(this).attr("value");
        $.ajax({
            type: 'post',
            data: "collection_id=" + collection + "&associated_product_id=" + associated_product + "&checked=" + this.checked,
        //data: {"collection_id": collection }}
            url: window.location.pathname
        });
    });
});
