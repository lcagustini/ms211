$(document).ready(function () {
    'use strict';
    //Lightbox
    $('.lightbox').lightbox();
    //Admin
    $('.overlay').hide();
    $('.overlay').find('name').remove();
    $("li.drag").hover(function () {
        $(this).find('.overlay').fadeIn(300);
    }, function () {
        $(this).find('.overlay').hide();
    });
    //alert("body");
    $('#menu ul li, .admin-header .menu ul li').hover(
        function () {
            $('ul', this).fadeIn(300);
        }, 
        function () {
            $('ul', this).slideUp(200);      
    });
      /* $('#menu ol').hover(
        function () {
          $(this).css('height', '90px');
          $('ol', this).slideDown(100);
        }, 
        function () { 
          $(this).css('height', '45px');
          $('ol', this).slideUp(200);      
      });   
    */

    //Tabela Admin
    $('.admin-content table tr:odd').css('background', '#f5f5f5'); 
    $('table.acabados tr:odd').css('background', '#ECECEC'); 
    
    // Scroll
    $('#submenu ul li').bind('click', function (event) {
        var $anchor = $(this).find('a');

        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1000);

        event.preventDefault();
    });

    //Menu             
    $("#header #menu ul li, #page #description .noticia, #page #description .arquivo, #page #description .busca").click(function () {
        window.location = $(this).find("a").attr("href");
        return false;
    });
    //Posts com Imagem           
    $("#page #description .post.com-imagem").click(function () {
        //window.location = $(this).find("a.mais").attr("href");
        //return false;
    });

    //Posts sem Imagem 
    $("#page #description .post.sem-imagem").click(function(){
		var thislink = $(this).find("a.blue");
			if ( thislink.attr('target') == '_blank') // Se tem o target="_blank", abre em nova aba.
				window.open(thislink.attr("href"));
			else
				window.location=thislink.attr("href");
      return false;
   });

    //Breadcrumb 
    $('<span>/</span>').appendTo('#page #description ul.breadcrumb li');
    $('#page #description ul.breadcrumb li.last, #page #description ul.breadcrumb li:last').find('span').remove();


    //Submenu
    $('<span class="corner left"></span><span class="corner right"></span>').appendTo('#submenu ul');


    //Boxes
    $('#boxes ul li').hover(function () {
        $(this).addClass('hover');
        $(this).find('.imagem').addClass('hover');
    }, function () {
        $(this).removeClass('hover');
        $(this).find('.imagem').removeClass('hover');
    });

    //Boxes
    $("#boxes ul li").click(function () {
        window.location = $(this).find("a").attr("href");
        return false;
    });

    // Menu
    $('#menu ul li').hover(function () {
        $('ul', this).fadeIn(300);
    }, function () {
        $('ul', this).slideUp(200);  
    });

    //Forms
    $(".uniform, .text, textarea, #resume_state, #budget_form_unit, #tipo, #catalog_form_unit").uniform();
    //$('#mensagem').limit('5000','#restantes span');

    // Custon Accordion
    //$('.accordionContent:first, #ativo.accordionContentProduto').show();	
    
    var $defined = function(obj)
    {
      return (obj != undefined);
    };

    // Produtos - Lançamentos
    var obj = $("#acabados ul li").find("a").attr("href");
    if( $defined(obj) )
    {
      $("#acabados ul li").click(function()
      {
    		window.location=$(this).find("a").attr("href");
        return false;
	    });
    }

	$('#acabados ul li').hover(function(){ 
		$(this).addClass('hover'); 
		$(this).find('.imagem').addClass('hover'); 
			},function(){ 
		$(this).removeClass('hover'); 
		$(this).find('.imagem').removeClass('hover'); 
	}); 
});
