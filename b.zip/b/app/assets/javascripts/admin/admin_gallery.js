$(function () {
    'use strict';
    $(".admin-gallery").sortable({
        opacity: 0.4,
        revert: true,
        scroll: true,
        handle: $("ul.admin-gallery li").add("ul.admin-gallery li img"),
        update: function (event, ui) {
            $.ajax({
                type: 'post',
                data: $('ul.admin-gallery').sortable('serialize'),
                dataType: 'script',
                complete: function (request) { $('ul.admin-gallery').effect('highlight'); },
                url: window.location.pathname + '/sort'
            });
        }
    });
});
