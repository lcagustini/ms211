$(function () {
  //http://www.isocra.com/2008/02/table-drag-and-drop-jquery-plugin/
    'use strict';
    $('#sort').tableDnD({
        onDrop: function (table, row) {
            $.ajax({
                type: "post",
                url: window.location.pathname + '/sort' + window.location.search,
                processData: false,
                data: $.tableDnD.serialize(),
                success: function (msg) { $(row).effect('highlight'); }
            });
        }
    });
});
