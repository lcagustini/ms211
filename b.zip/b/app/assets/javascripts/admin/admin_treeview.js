$(function () {
    'use strict';
    $("#admin-treeview").treeview({
    		animated: "fast",
    	 	collapsed: true,
     	 	persist: "cookie"
    });
});
