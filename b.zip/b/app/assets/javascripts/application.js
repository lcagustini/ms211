//= require namespace
//= require_tree ./vendors/
//= require_tree ./plugins
//= require_tree ./views
//= require collapse_categories_menu
//= require tabs
//= require product_slider_change
//= require config
