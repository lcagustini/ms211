Alpex.viewCustonInput = function () {
    'use strict';
	$("input[type='text'], select, textarea").uniform();
};