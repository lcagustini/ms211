Alpex.viewMenuHeader = function () {
		'use strict';
		var $menu = $('#menu');
		$menu.find('> ul > li').hover(
				function () { 
						$(this).find('ul').fadeToggle("slow"); 
				} 
		);
};

