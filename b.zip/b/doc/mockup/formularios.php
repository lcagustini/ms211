<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="" />

<title>Alpex - Sustentabilidade</title>

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<?php include ('includes/submenu-sobre.php'); ?>

<div id="page">
	<div id="categories">
		<div class="collapse"> 
			<div class="accordionButton"><h3>Saiba Mais</h3><span class="visitado"></span></div>
		  	<div class="accordionContent">
                    <ul>
                        <li>Conteúdo</li>
                    </ul> 
			</div> 
			<div class="accordionButton"><h3>Envie para um amigo</h3><span></span></div>
		  	<div class="accordionContent">
                    <ul>
                        <li>Conteúdo</li>
                    </ul> 
			</div>
 		</div> <!-- /collapse -->
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Sobre a Alpex">Sobre a Alpex</a></li>
		<li class="last"><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
	</ul>
	
	<div id="example">
	
          <form>
			<h4>Inputs</h4>
			<input type="text" id="" name="" value="Pequeno" class="text pequeno">
			<input type="text" id="" name="" value="Médio" class="text medio">
			<input type="text" id="" name="" value="Grande" class="text grande"> 
			
		    <br class="clear" />  
              <h4>Select Dropdown</h4>
              <div class="selector" id="uniform-"><span style="-moz-user-select: none;">Option 1</span><select style="opacity: 0;">
                <option value="option1">Option 1</option>
                <option value="option2">Option 2</option>
                <option value="option3">Option 3</option>
              </select> 
             </div>     
		   
		   <br class="clear" /><br /><br />
		   <h4>Radio Buttons</h4>		    
		    <label>
                <div class="radio" id="uniform-"><span><input type="radio" value="radio1" name="rgroup" style="opacity: 0;"></span></div>
                Radio 1
              </label>
              <label>
                <div class="radio" id="uniform-"><span class="checked"><input type="radio" value="radio2" name="rgroup" checked="checked" style="opacity: 0;"></span></div>
                Radio 2
              </label>
              <label>
                <div class="radio disabled" id="uniform-"><span><input type="radio" value="radio3" name="rgroup" disabled="disabled" style="opacity: 0;"></span></div>
                Radio 3
              </label>          
		  
		  <br class="clear" /><br /><br /> 
		  <h4>Checkboxes</h4>              
		    <label>
                <div class="checker" id="uniform-"><span><input type="checkbox" value="check1" style="opacity: 0;"></span></div>
                Checkbox 1
              </label>
              <label>
                <div class="checker" id="uniform-"><span class="checked"><input type="checkbox" value="check2" checked="checked" style="opacity: 0;"></span></div>
                Checkbox 2
              </label>
              <label>
                <div class="checker disabled" id="uniform-"><span><input type="checkbox" value="check3" disabled="disabled" style="opacity: 0;"></span></div>
                Checkbox 3
              </label>
		  
		  
		  <br class="clear" /><br /><br />
		  <h4>File Upload</h4>
		  <div class="uploader" id="uniform-">
		  	<input type="file" class="file" style="opacity: 0;">
		  	<span class="filename" style="-moz-user-select: none;">Nenhum Arquivo</span><span class="action" style="-moz-user-select: none;">Selecionar</span> 
            </div>
		  
		  <br class="clear" /><br /><br />
		  <h4>Textarea</h4>
		  <textarea class="text grande"></textarea>
		  <br class="clear" /><br /><br /><br /><br />
		  
		</form>		
</div>
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
