<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Trabalhe Conosco</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/jquery.limit.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	//Forms
	$("select#area, input.text, textarea").uniform();
	$('#curriculo').limit('5000','#restantes span');
}); 
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li><a href="sac.php" title="SAC">SAC</a></li>
		<li><a href="orcamento.php" title="Orçamento">Orçamento</a></li> 
		<li><a href="como-chegar.php" title="Como Chegar">Como Chegar</a></li> 
		<li><a href="fale-conosco.php" title="Fale Conosco">Fale Conosco</a></li> 
		<li class="ativo"><a href="trabalhe-conosco.php" title="Trabalhe Conosco">Trabalhe Conosco</a></li> 
		<li><a href="atendimento.php" title="Atendimento e Vendas">Atendimento</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description" class="fale-conosco">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Contato">Contato</a></li>
		<li class="last"><a href="#" title="Trabalhe Conosco">Trabalhe Conosco</a></li>
	</ul>
	
	<h4>Trabalhe Conosco</h4>
	<p>Se desejar, você pode enviar seu currículo para <a class="blue2"href="mailto:recrutamento@alpex.com.br">recrutamento@alpex.com.br</a>. <br />
	Os campos marcados com (<span class="blue">*</span>) são de preenchimento obrigatótio.</p> 

			<form class="forms" action="" method="POST">
				<fieldset>				
				   <label for="area">Área de interesse <span class="blue">*</span></label>
				   <select id="area" name="area">
						<option>Departamento de Vendas</option>
						<option>Departamento de Vendas</option>
						<option>Departamento de Vendas</option>
						<option>Departamento de Vendas</option>
						<option>Departamento de Vendas</option>
						<option>Departamento de Vendas</option>
						<option>Departamento de Vendas</option>
					</select>
				   <br class="clear" />
				   <label for="nome">Nome <span class="blue">*</span></label>
				   <input class="text trabalhe" type="text" name="nome" id="nome">
				   
				   <label for="email">Email <span class="blue">*</span></label>
				   <input class="text trabalhe" type="text" name="email" id="email">
				   
				   <label for="ddd">Telefone <span class="blue">*</span></label>
				   <input class="text ddd" type="text" name="ddd" id="ddd">
				   <input class="text telefone" type="text" name="telefone" id="telefone">
				   
				   <label for="anexar">Anexar <span class="blue">*</span></label>
				   <div class="uploader" id="uniform" style="margin:6px 0 0 -3px">
					<input type="file" class="file" id="anexar" style="opacity: 0;">
					<span class="filename" style="-moz-user-select: none;">Nenhum Arquivo</span><span class="action" style="-moz-user-select: none;">Anexar</span> 
				  </div>
				   <br class="clear" />
				   <label for="curriculo">Mini Currículo <span class="blue">*</span> 
				   <span class="descreva">Descreva brevemente seu currículo de acordo com a área desejada.</span></label>
				   <textarea class="envie trabalhe" name="curriculo" id="curriculo" rows="3" cols="50"></textarea>				   
				   				   
				   <p id="restantes" class="legenda">Restam <span class="blue"></span> caracteres.</p>
				   			   
				</fieldset>
			</form>
	
	<br class="clear" />
	
	<ul class="enviar trabalhe">
		<li><a class="button-blue" href="#" title="Limpar">Limpar</a></li>
		<li><a class="button-blue" href="#" title="Enviar">Enviar</a></li>
	</ul>
	
	<br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div> 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
