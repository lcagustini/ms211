<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Links Úteis</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/jquery.limit.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	//Forms
	$("select#area, .text, textarea").uniform();
	$('#mensagem').limit('5000','#restantes span');
}); 
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="haste"></div> <!-- /haste-->

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Home">Home</a></li>
		<li class="last"><a href="#" title="Links Úteis">Links Úteis</a></li>
	</ul>
	
	<h4>Links Úteis</h4>
	<p></p>
	<div class="vendas">
		<h5>Entidades Nacionais</h5>
			<ul>
				<li><a href="http://www.abal.org.br/" title="ABAL" target="_blank">ABAL - Assossiação Brasileira do Alumínio</a></li>
				<li><a href="http://www.andiv.com.br/" title="Abravidro" target="_blank">Abravidro - Associação Brasileira de Distribuidores e Processadores de Vidros Planos</a></li>
				<li><a href="http://www.abrapebrasil.com.br/" title="ABRAPE" target="_blank">ABRAPE - Associação Brasileira de Persianas e Cortinas</a></li>
				<li><a href="http://www.siamfesp.org.br/" title="SIAMFESP" target="_blank">SIAMFESP - Sindicato da Indústria de Artefatos de Metais não Ferrosos no Estado de São Paulo</a></li>
			</ul>
		<br class="clear" />
			
		<h5>Entidades Internacionais</h5>
			<ul>
				<li><a href="http://www.eaa.net/" title="EAA" target="_blank">European aluminium association - EAA</a></li>
				<li><a href="http://www.world-aluminium.org/" title="IAI" target="_blank">International Aluminium Institute - IAI</a></li>
				<li><a href="http://www.aluminum.org/" title="TAA" target="_blank">The Aluminum Association</a></li>
			</ul>
	</div>
	
	<br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div> 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
