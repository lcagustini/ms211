$(document).ready(function(){

	// Scroll
	$('#submenu ul li').bind('click',function(event){
		var $anchor = $(this).find('a');

		$('html, body').stop().animate({
			scrollTop: $($anchor.attr('href')).offset().top
		}, 1000);
		 
		event.preventDefault();
	});
	
	//Menu					   
	$("#header #menu ul li, #page #description .post, #page #description .arquivo, #page #description .busca, #page #description .noticia").click(function(){
    		window.location=$(this).find("a").attr("href");return false;
	}); 
	
	//Breadcrumb
	$('<span>/</span>').appendTo('#page #description ul.breadcrumb li');
	$('#page #description ul.breadcrumb li.last').find('span').remove();
	
	
	//Submenu
	$('<span class="corner left"></span><span class="corner right"></span>').appendTo('#submenu ul');
	
	
	 
});