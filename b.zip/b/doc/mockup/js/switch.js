$(document).ready(function(){
		
		/*$("#produto1 a.change").click(function(){
			$(this).removeClass('change').addClass('change-back');
			$("#produto1 .slice").animate({"left": "-140px"}, "fast");
		});
		$("#produto1 a.change-back").click(function(){
			$(this).removeClass('change-back').addClass('change');
			$("#produto1 .slice").animate({"left": "140px"}, "fast");
		});*/
	$('#produto1 a.change').click(function(){ 
		$("#produto1 .slice").animate({"left": "-140px"}, "fast");
	},function(){
		$("#produto1 .slice").animate({"left": "0"}, "fast");
	});

		
});