<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Envie para um amigo</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="haste"></div>

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Sobre a Alpex">Sobre a Alpex</a></li>
		<li class="last"><a href="#" title="Envie para um amigo">Envie para um amigo</a></li>
	</ul>
	
	<h4>Envie para um amigo</h4>
	<p>Veja abaixo as páginas selecionadas por você para o envio.</p> 

	<textarea class="envie">
1. Sustentabilidade - www.alpex.com.br/sustentabilidade
2. Produtos Acabados / Linha Rimini - www.www.alpex.com.br/ 
produtos acabados	
	</textarea>
	
	<ul class="enviar">
		<li><a class="button-blue" href="#" title="enviar agora">enviar agora</a></li>
		<li><a class="button-blue" href="#" title="continuar navegando">continuar navegando</a></li>
	</ul>
	
	<br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div> 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
