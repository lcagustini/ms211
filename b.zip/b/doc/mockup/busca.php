<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
 
<title>Alpex – Resultado da Busca po 'X'</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" /> 
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" /> 

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script> 
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script> 
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul>  
		<li class="ativo"><a href="#" title="Busca Avançada">Busca Avançada</a> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Home">Home</a></li>
		<li class="last"><a href="#" title="Resultado da Busca">Resultado da Busca</a></li>
	</ul>
	
	<h4>Busca</h4>
	<p>Foram encontrados aproximadamente <span class="black">142.000.000</span> resultados</p>
	
	<br class="clear" />
	
	<div class="busca">
		<h5>Testes - CAPRICHO</h5>
		<a href="http://www.capricho.abril.com.br/" class="url">capricho.abril.com.br/testes/</a>
		<p>Em qual cor no melhor teste profissional deve apostar no ano  profissões e vão combinam com você no melhor teste profissional da internet...</p> 
	</div>
	
	<div class="busca">
		<h5>Testes - CAPRICHO</h5>
		<a href="http://www.capricho.abril.com.br/" class="url">capricho.abril.com.br/testes/</a>
		<p>Em qual cor no melhor teste profissional deve apostar no ano  profissões e vão combinam com você no melhor teste profissional da internet...</p> 
	</div>
	
	<div class="busca">
		<h5>Testes - CAPRICHO</h5>
		<a href="http://www.capricho.abril.com.br/" class="url">capricho.abril.com.br/testes/</a>
		<p>Em qual cor no melhor teste profissional deve apostar no ano  profissões e vão combinam com você no melhor teste profissional da internet...</p> 
	</div>
	
	<div class="busca">
		<h5>Testes - CAPRICHO</h5>
		<a href="http://www.capricho.abril.com.br/" class="url">capricho.abril.com.br/testes/</a>
		<p>Em qual cor no melhor teste profissional deve apostar no ano  profissões e vão combinam com você no melhor teste profissional da internet...</p> 
	</div>
	
	<div class="busca">
		<h5>Testes - CAPRICHO</h5>
		<a href="http://www.capricho.abril.com.br/" class="url">capricho.abril.com.br/testes/</a>
		<p>Em qual cor no melhor teste profissional deve apostar no ano  profissões e vão combinam com você no melhor teste profissional da internet...</p> 
	</div>
	
	<br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	<ul class="paginacao">
		<li><a href="#" title="Anterior">◄</a></li>
		<li><a class="ativo" href="#" title="1">1</a></li>
		<li><a href="#" title="2">2</a></li>
		<li><a href="#" title="3">3</a></li>
		<li><a href="#" title="4">4</a></li>
		<li><a href="#" title="5">5</a></li>
		<li><a href="#" title="6">6</a></li>
		<li><a href="#" title="7">7</a></li>
		<li><a href="#" title="Próxima">►</a></li>
	</ul>
	
	<br class="clear" /> 	
	
	</div>
	 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
