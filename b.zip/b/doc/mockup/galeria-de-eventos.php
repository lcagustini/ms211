<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Galeria de Eventos</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" /> 
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" /> 
<link rel="stylesheet" type="text/css" href="css/jquery.ui.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script> 
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script> 
<script type="text/javascript" src="js/lightbox.js" charset="utf-8"></script>  
<script type="text/javascript">
$(document).ready(function($){ 
	$('<span class="corner left"></span><span class="corner right"></span>').appendTo('#submenu ul');
	$('.lightbox').lightbox();
	$('<span>/</span>').appendTo('#page #description ul.breadcrumb li');
	$('#page #description ul.breadcrumb li.last').find('span').remove();	
});
</script>
	
</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li class="ativo"><a href="#" title="Próximos">Próximos</a></li>
		<li><a href="#" title="Realizados">Realizados</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		
		<div class="produtos">
			<div class="accordionButtonProduto"><h4>Alpex</h4><span></span></div> 
			<div class="accordionButtonProduto"><h3>Do Setor</h3></div> 
		</div>
	
		<div class="collapse">
			<div class="accordionSemButton"><a href="" title="Saiba Mais">Saiba Mais</a><span></span></div>
			<div class="accordionButton"><h3>Envie para um amigo</h3><span></span></div>
				<div class="accordionContent">
					<div class="envie">
						<ul>
							<li>
								<input type="text" id="nome" name="nome" value="digite seu nome" onfocus="if (this.value == 'digite seu nome') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu nome';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="seu-email" name="seu-email" value="digite seu email" onfocus="if (this.value == 'digite seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu email';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="email-amigo" name="email-amigo" value="insira o email do seu amigo" onfocus="if (this.value == 'insira o email do seu amigo') {this.value = '';}" onblur="if (this.value == '') {this.value = 'insira o email do seu amigo';}" class="text pequeno">
							</li>			
						</ul>
						
						<a class="button-blue" href="#" title="enviar agora">enviar agora</a>
						<a class="button-blue" href="#" title="continuar navegando">continuar navegando</a>
						
						<br class="clear" />
						
					</div> <!-- /envie -->
				</div>
		</div> <!-- /collapse -->
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Eventos">Eventos</a></li>
		<li><a href="#" title="Alpex">Alpex</a></li>
		<li><a href="#" title="Janeiro">Janeiro</a></li>
		<li><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
		<li class="last"><a href="#" title="Galeria de Imagens">Galeria de Imagens</a></li>
	</ul>
	
	<br />
	
	<div class="post com-galeria">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		
		<ul class="galeria">
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app3.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app3.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app3.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app3.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app3.jpg" alt="" title="" /></a></li>
		<li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
		</ul>
		
		<br class="clear" />
		
	</div>
	
	<br class="clear" /> 
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	<ul class="paginacao">
		<li><a href="#" title="Anterior">◄</a></li>
		<li><a class="ativo" href="#" title="1">1</a></li>
		<li><a href="#" title="2">2</a></li>
		<li><a href="#" title="3">3</a></li>
		<li><a href="#" title="4">4</a></li>
		<li><a href="#" title="5">5</a></li>
		<li><a href="#" title="6">6</a></li>
		<li><a href="#" title="7">7</a></li>
		<li><a href="#" title="Próxima">►</a></li>
	</ul>
	
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
