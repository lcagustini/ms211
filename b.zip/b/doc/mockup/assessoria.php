<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Sala de Imprensa | Assessoria de Imprensa</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/jquery.limit.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	//Forms
	$("select#area, select#assunto, input.text, textarea").uniform();
	$('#mensagem').limit('1024','#restantes span');
}); 
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="haste"></div>

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Sala de Imprensa">Sala de Imprensa</a></li>
		<li class="last"><a href="#" title="Assessoria de Imprensa">Assessoria de Imprensa</a></li>
	</ul>
	
	<h4>Assessoria de Imprensa</h4>
	<p>Entre em contato com a assessoria de imprensa da Alpex:</p>
	
	<div class="vendas">
		<h5>Ponto &amp; Vírgula Comunicação</h5>
			<ul>
				<li>Fabiana Salviano</li>
			</ul>
			<p class="no-margin">E-mail: <a href="mailto:fabiana@pontovirgula.com.br" title="">fabiana@pontovirgula.com.br</a></p>
			<ul>
				<li>Mariana Leite</li>
			</ul>
			<p>E-mail: <a href="mailto:mariana@pontovirgula.com.br" title="">mariana@pontovirgula.com.br</a></p>	
			
			<p>
			<strong>Contato:</strong> (11) 4107-2854 / 2866-0933 <br />
			<strong>Site:</strong> <a href="http://www.pontovirgula.com.br" target="_blank" title="Ponto &amp; Vírgula Comunicação">www.pontovirgula.com.br</a>
			</p>	
	</div>
	
	<br /><br /><br /><br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div> 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
