<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Cotação LME</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="alpex, alumínio, sustentabilidade, responsabilidade, social, ambiental, reciclagem, alumínio, sustentável" />
<meta name="description" content="A Alpex Alumínio tem o compromisso de manter seu desenvolvimento de maneira sustentável, respeitando o meio ambiente e as pessoas." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript" src="js/tablesorter.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){	
	$('#ativo').show();
	$('.accordionContent:first').hide();
	
	$("table.tablesorter").tablesorter({});  
	$("table.tablesorter tr:odd").css("background-color", "#ececec");
});
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li class="ativo"><a href="#" title="Semanal">Semanal</a></li>
		<li><a href="#" title="Quinzenal">Quinzenal</a></li> 
		<li><a href="#" title="Mensal">Mensal</a></li> 
		<li><a href="#" title="Semestral">Semestral</a></li> 
		<li><a href="#" title="Anual">Anual</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		
		<div class="produtos">
			<div class="accordionButtonProduto"><h3>2012</h3></div> 
				<div class="accordionContentProduto">
					<ul>
						<li><a href="" title="Janeiro">Janeiro</a></li>
						<li><a href="" title="Fevereiro">Fevereiro</a></li>
						<li><a href="" title="Março">Março</a></li>
						<li><a href="" title="Abril">Abril</a></li>
						<li><a href="" title="Maio">Maio</a></li>
						<li><a href="" title="Junho">Junho</a></li>
						<li><a href="" title="Julho">Julho</a></li>
						<li><a href="" title="Agosto">Agosto</a></li>
						<li><a href="" title="Setembro">Setembro</a></li>
						<li><a href="" title="Outubro">Outubro</a></li>
						<li><a href="" title="Novembro">Novembro</a></li>
						<li><a href="" title="Dezembro">Dezembro</a></li>
					</ul>
				</div> 
			<div class="accordionButtonProduto"><h4>2011</h4><span></span></div> 
				<div class="accordionContentProduto" id="ativo">
					<ul>
						<li><a href="" title="Janeiro">Janeiro</a></li>
						<li><a href="" title="Fevereiro">Fevereiro</a></li>
						<li><a href="" title="Março">Março</a></li>
						<li><a href="" title="Abril">Abril</a></li>
						<li><a href="" title="Maio">Maio</a></li>
						<li><a href="" title="Junho">Junho</a></li>
						<li><a href="" title="Julho">Julho</a></li>
						<li><a href="" title="Agosto">Agosto</a></li>
						<li><a href="" title="Setembro">Setembro</a></li>
						<li><a href="" title="Outubro">Outubro</a></li>
						<li><a href="" title="Novembro">Novembro</a></li>
						<li><a href="" title="Dezembro">Dezembro</a></li>
					</ul>
				</div>
		</div>		
		
		<p>Os valores da LME referem-se à média entre o CASH BUYER e CASH SELLER & SETTLEMENT.</p>
		<p><strong>Dólar</strong> - Os dados fornecidos referem-se ao fechamento do dia anterior divulgado pelo Banco Central do Brasil. </p>
		
		<div class="collapse lme">
			<div class="accordionSemButton"><a href="" title="Saiba Mais">Saiba Mais</a><span></span></div>
			<div class="accordionButton"><h3>Envie para um amigo</h3><span></span></div>
				<div class="accordionContent">
					<div class="envie">
						<ul>
							<li>
								<input type="text" id="nome" name="nome" value="digite seu nome" onfocus="if (this.value == 'digite seu nome') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu nome';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="seu-email" name="seu-email" value="digite seu email" onfocus="if (this.value == 'digite seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu email';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="email-amigo" name="email-amigo" value="insira o email do seu amigo" onfocus="if (this.value == 'insira o email do seu amigo') {this.value = '';}" onblur="if (this.value == '') {this.value = 'insira o email do seu amigo';}" class="text pequeno">
							</li>			
						</ul>
						
						<a class="button-blue" href="#" title="enviar agora">enviar agora</a>
						<a class="button-blue" href="#" title="continuar navegando">continuar navegando</a>
						
						<br class="clear" />
						
					</div> <!-- /envie -->
				</div>
		</div> <!-- /collapse -->
		
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Home">Home</a></li>
		<li class="last"><a href="#" title="Cotação LME">Cotação LME</a></li>
	</ul>
	
	<h4>Cotação LME</h4>
	<div class="date black">Dia 19/01/2012</div>
	
	<table class="tablesorter" cellspacing="1">             
	    <thead>  
		   <tr> 
			  <th class="dia">Dia</th> 
			  <th class="dolar">Dólar</th> 
			  <th class="aluminio">Alumínio</th> 
			  <th class="valor">Valor Total</th>  
		   </tr> 
	    </thead> 
	    <tbody> 
		   <tr> 
			  <td class="dia">01/01/2012</td> 
			  <td class="dolar">U$ 1,23</td> 
			  <td class="aluminio">1,23</td> 
			  <td class="valor">R$ 1,23</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">01/01/2012</td> 
			  <td class="dolar">U$ 1,21</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,26</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">04/01/2012</td> 
			  <td class="dolar">U$ 1,27</td> 
			  <td class="aluminio">2,23</td> 
			  <td class="valor">R$ 0,28</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">05/01/2012</td> 
			  <td class="dolar">U$ 1,22</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,25</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">06/01/2012</td> 
			  <td class="dolar">U$ 1,21</td> 
			  <td class="aluminio">1,21</td> 
			  <td class="valor">R$ 1,21</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">07/01/2012</td> 
			  <td class="dolar">U$ 1,29</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,21</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">08/01/2012</td> 
			  <td class="dolar">U$ 1,26</td> 
			  <td class="aluminio">1,27</td> 
			  <td class="valor">R$ 1,24</td>  
		   </tr>  
		   <tr> 
			  <td class="dia">01/01/2012</td> 
			  <td class="dolar">U$ 1,21</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,26</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">04/01/2012</td> 
			  <td class="dolar">U$ 1,27</td> 
			  <td class="aluminio">2,23</td> 
			  <td class="valor">R$ 0,28</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">05/01/2012</td> 
			  <td class="dolar">U$ 1,22</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,25</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">06/01/2012</td> 
			  <td class="dolar">U$ 1,21</td>
			  <td class="aluminio">1,21</td>  
			  <td class="valor">R$ 1,21</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">01/01/2012</td> 
			  <td class="dolar">U$ 1,21</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,26</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">04/01/2012</td> 
			  <td class="dolar">U$ 1,27</td> 
			  <td class="aluminio">2,23</td> 
			  <td class="valor">R$ 0,28</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">05/01/2012</td> 
			  <td class="dolar">U$ 1,22</td> 
			  <td class="aluminio">1,22</td> 
			  <td class="valor">R$ 1,25</td>  
		   </tr> 
		   <tr> 
			  <td class="dia">06/01/2012</td> 
			  <td class="dolar">U$ 1,21</td> 
			  <td class="aluminio">1,21</td> 
			  <td class="valor">R$ 1,21</td>  
		   </tr> 
	    </tbody> 
	</table>
	
	<br />
	
	<div class="grafico">
		<img src="images/grafico.gif" alt="" title="" />
	</div> <!-- /grafico  -->
	
	<br />
	<br />
	
	<a class="anterior" href="#" title="Anterior">anterior</a>
		<span class="barra">/</span>
	<a class="proxima" href="#" title="Próxima">próxima</a>	
	
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
