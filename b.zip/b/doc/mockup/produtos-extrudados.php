<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Produtos Extrudados | Perfis de Alumínio em Barra e Sob Medida</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="Alpex, alumínio, Alpex Produtos Extrudados, perfil extrudado, perfil de alumínio, perfil de alumínio em barra" />
<meta name="description" content="Alpex Produtos Extrudados fornece perfil de alumínio extrudado para aplicação nos mais variados segmentos." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/tabs.js" charset="utf-8"></script>
<script type="text/javascript" src="js/switch.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript" src="js/lightbox.js" charset="utf-8"></script>
<script type="text/javascript">
jQuery(document).ready(function($){	
	$('.accordionContent:first, #ativo.accordionContentProduto').show();	
	$('.lightbox').lightbox();
});
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="produto">
	<object width="100%" height="480" type="application/x-shockwave-flash" data="flash/produtos.swf" title="Sustentabilidade">
		<param name="movie" value="flash/produtos.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="haste"></div> <!-- /haste-->

<div id="page">
	<div id="categories">
		<div class="produtos">
			<div class="accordionButtonProduto"><h4>Extrudados</h4><span></span></div>
				<div class="accordionContentProduto" id="ativo">
					<ul>
						<li><a class="ativo" href="produtos-extrudados.php" title="Acessórios e Arremates">Acessórios e Arremates</a></li>
						<li><a href="produtos-extrudados.php" title="Box">Box</a></li>
						<li><a href="produtos-extrudados.php" title="Divisórias">Divisórias</a></li>
						<li><a href="produtos-extrudados.php" title="Esquadrias">Esquadrias</a></li>
						<li><a href="produtos-extrudados.php" title="Standard">Standard</a></li>
					</ul>
				</div> 
				<div class="accordionButtonProduto"><h3>Acabados</h3></div>
				<div class="accordionContentProduto">
					<ul>
						<li><a href="produtos-acabados.php" title="Linha Bellágio">Linha Bellágio</a></li>
						<li><a href="produtos-acabados.php" title="Linha Cristal">Linha Cristal</a></li> 
						<li><a href="produtos-acabados.php" title="Linha Millan">Linha Millan</a></li> 
						<li><a href="produtos-acabados.php" title="Linha Rimini">Linha Rimini</a></li> 
						<li><a href="produtos-acabados.php" title="Linha Roma">Linha Roma</a></li> 
						<li><a href="produtos-acabados.php" title="Linha Verona">Linha Verona</a></li> 
						<li><a href="produtos-acabados.php" title="Linha Light">Linha Light</a></li> 
						<li><a href="produtos-acabados.php" title="Porta de Abrir Basculante">Porta de Abrir Basculante</a></li> 
						<li><a href="produtos-acabados.php" title="Porta Deslizante">Porta Deslizante</a></li> 
						<li><a href="produtos-acabados.php" title="Trilho">Trilho</a></li> 
						<li><a href="produtos-acabados.php" title="Travessa">Travessa</a></li> 
						<li><a href="produtos-acabados.php" title="Puxador">Puxador</a></li> 
						<li><a href="produtos-acabados.php" title="Cabideiro">Cabideiro</a></li> 
						<li><a href="produtos-acabados.php" title="Testeira">Testeira</a></li> 
						<li><a href="produtos-acabados.php" title="Porta CD e DVD">Porta CD e DVD</a></li> 
						<li><a href="produtos-acabados.php" title="Prateleira de Calceiro">Prateleira de Calceiro</a></li> 
						<li><a href="produtos-acabados.php" title="Acessórios">Acessórios</a></li> 
						<li><a href="produtos-acabados.php" title="Esquadretas">Esquadretas</a></li> 
						<li><a href="produtos-acabados.php" title="Comentários">Comentários</a></li> 
						<li><a href="produtos-acabados.php" title="Painéis Decorativos">Painéis Decorativos</a></li> 
					</ul>
				</div>
				<div class="accordionButtonProduto"><h3>Lançamentos</h3></div> 
				<div class="accordionButtonProduto"><h3>Sistemas</h3></div> 
			</div>
		
		<div class="collapse"> 
			<div class="accordionButton"><h3>Veja algumas aplicações</h3><span class="visitado"></span></div>
		  	<div class="accordionContent">                    
				<ul class="apps">
                        <li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app1.jpg" alt="" title="" /></a></li>
                        <li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app2.jpg" alt="" title="" /></a></li>
                        <li><a href="images/maximizada1.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app3.jpg" alt="" title="" /></a></li>
                        <li><a href="images/maximizada.jpg" class="lightbox inset" rel="aplicacoes" title="Legenda da Aplicação"><img src="images/app4.jpg" alt="" title="" /></a></li>
                    </ul>
			</div> 
			<br class="clear" />
			<div class="accordionButton"><h3>Envie para um amigo</h3><span></span></div>
		  	<div class="accordionContent">
                    <div class="envie">
				<ul>
					<li>
						<input type="text" id="nome" name="nome" value="digite seu nome" onfocus="if (this.value == 'digite seu nome') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu nome';}" class="text pequeno">
					</li>
					<li>
						<input type="text" id="seu-email" name="seu-email" value="digite seu email" onfocus="if (this.value == 'digite seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu email';}" class="text pequeno">
					</li>
					<li>
						<input type="text" id="email-amigo" name="email-amigo" value="insira o email do seu amigo" onfocus="if (this.value == 'insira o email do seu amigo') {this.value = '';}" onblur="if (this.value == '') {this.value = 'insira o email do seu amigo';}" class="text pequeno">
					</li>			
				</ul>
				
				<a class="button-blue" href="#" title="enviar agora">enviar agora</a>
				<a class="button-blue" href="#" title="continuar navegando">continuar navegando</a>
				
				<br class="clear" />
				
			</div> <!-- /envie -->
			</div> 
			<div class="accordionSemButton"><a href="" title="Saiba Mais">Saiba Mais</a><span></span></div>
 		</div> <!-- /collapse -->
	</div> <!-- /categories -->
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Produtos">Produtos</a></li>
		<li><a href="#" title="Extrudados">Extrudados</a></li>
		<li class="last"><a href="#" title="Acessórios e Arremates">Acessórios e Arremates</a></li>
	</ul>
	
	<h4>Acessórios e Arremates</h4>
	<p>Curabitur at dolor in ligula eleifend tempor. Nam vitae tortor ut lectus sollicitudin lobortis in eget est. Ut non lacus nulla. Nunc ut ultricies libero. </p>
	
	<ul class="produtos-extrudados">
		<li>
			<div class="imagem">
				<input type="checkbox" id="peca1" name="peca1" />
				<label for="peca1"><img src="images/extrudados1.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1805</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<input type="checkbox" id="peca2" name="peca2" />
				<label for="peca2"><img src="images/extrudados2.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1823</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<input type="checkbox" id="peca3" name="peca3" />
				<label for="peca3"><img src="images/extrudados3.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1256</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li class="right">
			<div class="imagem">
				<input type="checkbox" id="peca4" name="peca4" />
				<label for="pec4"><img src="images/extrudados4.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1452</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<input type="checkbox" id="peca5" name="peca5" />
				<label for="peca5"><img src="images/extrudados5.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1805</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<input type="checkbox" id="peca6" name="peca6" />
				<label for="peca6"><img src="images/extrudados6.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1823</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<input type="checkbox" id="peca7" name="peca7" />
				<label for="peca7"><img src="images/extrudados7.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1256</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		<li class="top right">
			<div class="imagem">
				<input type="checkbox" id="peca8" name="peca8" />
				<label for="peca8"><img src="images/extrudados8.jpg" alt="" title="" /></label>
			</div>
			<div class="opcoes">
				<span>1452</span>
				<a href="images/maximizada.jpg" class="lightbox details" rel="extrudados" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer dignissim ipsum nec sem scelerisque quis faucibus quam scelerisque. Sed quis arcu purus. Donec at lacus nec leo laoreet viverra at ac risus. Vivamus ipsum orci, interdum ut commodo sodales, ullamcorper a felis.">Detalhes</a>
			</div>
		</li>
		 
		
		<br class="clear" />
	</ul>
	
	
	<br />
	<br />
	<br />
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
