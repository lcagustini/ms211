<div class="collapse"> 
	<div class="accordionSemButton"><a href="" title="Saiba Mais">Saiba Mais</a><span></span></div>
	<div class="accordionButton"><h3>Envie para um amigo</h3><span class="visitado"></span></div>
		<div class="accordionContent">
			<div class="envie">
				<ul>
					<li>
						<input type="text" id="nome" name="nome" value="digite seu nome" onfocus="if (this.value == 'digite seu nome') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu nome';}" class="text pequeno">
					</li>
					<li>
						<input type="text" id="seu-email" name="seu-email" value="digite seu email" onfocus="if (this.value == 'digite seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu email';}" class="text pequeno">
					</li>
					<li>
						<input type="text" id="email-amigo" name="email-amigo" value="insira o email do seu amigo" onfocus="if (this.value == 'insira o email do seu amigo') {this.value = '';}" onblur="if (this.value == '') {this.value = 'insira o email do seu amigo';}" class="text pequeno">
					</li>			
				</ul>
				
				<a class="button-blue" href="#" title="enviar agora">enviar agora</a>
				<a class="button-blue" href="#" title="continuar navegando">continuar navegando</a>
				
				<br class="clear" />
				
			</div> <!-- /envie -->
		</div>
</div> <!-- /collapse -->