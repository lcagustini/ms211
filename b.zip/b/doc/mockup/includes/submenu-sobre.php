<div id="submenu">
	<ul> 
		<li><a href="#" title="História">História</a></li>
		<li><a href="#" title="Unidades">Unidades</a></li>
		<li<?php if ($url == "sustentabilidade.php"){ echo " class='ativo'";} ?>><a href="sustentabilidade.php" title="Sustentabilidade">Sustentabilidade</a></li>
		<li><a href="#" title="Sobre o Alumínio">Sobre o Alumínio</a></li>
		<li><a href="#" title="Certificados ISO">Certificados ISO</a></li>
	</ul>
</div> <!-- /submenu-->