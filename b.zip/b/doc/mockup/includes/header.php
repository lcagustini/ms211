<script type="text/javascript">
$(document).ready(function(){
	$('#menu ul li').hover(
		function () {
			$('ul', this).fadeIn(300);
		}, 
		function () {
			$('ul', this).slideUp(200);			
	});     
});
</script>

<div id="header">
	<h1><a href="index.php" title="Alpex">Alpex</a></h1>
	
	<div id="menu">
		<h2><a href="index.php" title="Home">Alpex</a></h2>
		<ul>
			<li class="sobre <?php if ($url == "sustentabilidade.php"){ echo "ativo";} ?>"><a href="sustentabilidade.php" title="Sobre a Alpex">Sobre a Alpex</a>
				<ul>
					<li><a href="sustentabilidade.php" title="História">História</a></li>
					<li><a href="sustentabilidade.php" title="Unidades">Unidades</a></li>
					<li><a href="sustentabilidade.php" title="Sustentabilidade">Sustentabilidade</a></li>
					<li><a href="sustentabilidade.php" title="Sobre o Alumínio">Sobre o Alumínio</a></li>
					<li><a href="sustentabilidade.php" title="Certificados ISO">Certificados ISO</a></li>
					<li><a href="sustentabilidade.php" title="Links Úteis">Links Úteis</a></li>
					<li><a href="sustentabilidade.php" title="LME">LME</a></li>
					<li class="last"></li>	
				</ul>
			</li>
			<li class="produtos <?php if ($url == "produtos-acabados.php"){ echo "ativo";} 
								 if ($url == "produtos-extrudados.php"){ echo "ativo";}
								 if ($url == "lancamentos.php"){ echo "ativo";} ?>"><a href="produtos-acabados.php" title="Produtos">Produtos</a>  
				<ul>
					<li><a href="produtos-extrudados.php" title="Extrudados">Extrudados</a></li>
					<li><a href="produtos-acabados.php" title="Acabados">Acabados</a></li>
					<li><a href="lancamentos.php" title="Lançamentos">Lançamentos</a></li>
					<li><a href="sistemas.php" title="Sistemas de Esquadrias">Sistemas de Esquadrias</a></li>
					<li class="last"></li>	
				</ul>  
			</li>
			<li<?php if ($url == "noticias.php"){ echo " class='ativo'";}
				    if ($url == "assessoria.php"){ echo " class='ativo'";} ?>><a href="noticias.php" title="Sala de Imprensa">Sala de Imprensa</a>
				<ul>
					<li><a href="noticias.php" title="Notícias da Alpex">Notícias da Alpex</a></li>
					<li><a href="assessoria.php" title="Assessoria de Imprensa">Assessoria de Imprensa</a></li>
					<li class="last"></li>	
				</ul>  
			</li>
			<li<?php if ($url == "eventos.php"){ echo " class='ativo'";} ?>><a href="eventos.php" title="Eventos">Eventos</a>
				<ul>
					<li><a href="eventos.php" title="Agenda da Alpex">Agenda da Alpex</a></li>
					<li><a href="eventos.php" title="Agenda do Setor">Agenda do Setor</a></li>
					<li><a href="eventos.php" title="Galeria de Fotos">Galeria de Fotos</a></li>
					<li class="last"></li>	
				</ul> 
			</li>
			<li<?php if ($url == "sac.php"){ echo " class='ativo'";}
				    if ($url == "orcamento.php"){ echo " class='ativo'";}
				    if ($url == "como-chegar.php"){ echo " class='ativo'";}
				    if ($url == "fale-conosco.php"){ echo " class='ativo'";}
				    if ($url == "trabalhe-conosco.php"){ echo " class='ativo'";}
				    if ($url == "atendimento.php"){ echo " class='ativo'";} ?>><a href="fale-conosco.php" title="Contato">Contato</a>
				<ul>
					<li><a href="sac.php" title="SAC">SAC</a></li>
					<li><a href="orcamento.php" title="Orçamento">Orçamento</a></li>
					<li><a href="como-chegar.php" title="Como Chegar">Como Chegar</a></li>
					<li><a href="fale-conosco.php" title="Fale Conosco">Fale Conosco</a></li>
					<li><a href="trabalhe-conosco.php" title="Trabalhe Conosco">Trabalhe Conosco</a></li>
					<li><a href="atendimento.php" title="Atendimento e Vendas">Atendimento e Vendas</a></li>
					<li class="last"></li>	
				</ul> 
			
			</li>
		</ul>
		<div id="search">
			<form method="get" action="">
				<input type="text" name="busca" id="busca" />
				<input type="submit" name="ok" id="ok" value="OK" />
			</form>
		</div>
	</div>
</div>  