<div id="footer">
	<div class="gridSystem">
		<ul>
			<li><h2><a href="#" title="Sobre a Empresa">Sobre a Empresa</a></h2></li>
			<li><a href="#" title="História">História</a></li>
			<li><a href="#" title="Unidades">Unidades</a></li>
			<li><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
			<li><a href="#" title="Sobre o Alumínio">Sobre o Alumínio</a></li>
			<li><a href="#" title="Certificados ISO">Certificados ISO</a></li>
		</ul>
		<ul class="second">
			<li><h2><a href="#" title="Produtos">Produtos</a></h2></li>
			<li><a href="#" title="Extrudados">Extrudados</a></li>
			<li><a href="#" title="Acabados">Acabados</a></li>
			<li><a href="#" title="Lançamentos">Lançamentos</a></li>
			<li><a href="#" title="Sistemas">Sistemas</a></li>
		</ul>
		<ul class="third">
			<li><h2><a href="#" title="Sala de Imprensa">Sala de Imprensa</a></h2></li>
			<li><a href="#" title="Notícias da Alpex">Notícias da Alpex</a></li>
			<li class="last"><a href="#" title="Assessoria de Imprensa">Assessoria de Imprensa</a></li>
		</ul>
		<ul class="cont">
			<li><h2><a href="#" title="Eventos">Eventos</a></h2></li>
			<li><a href="#" title="Agenda da Alpex">Agenda da Alpex</a></li>
			<li><a href="#" title="Agenda do Setor">Agenda do Setor</a></li>
			<li><a href="#" title="Galeria de Fotos">Galeria de Fotos</a></li>
		</ul>
		<ul>
			<li><h2><a href="#" title="Contato">Contato</a></h2></li>
			<li><a href="#" title="SAC">SAC</a></li>
			<li><a href="#" title="Orçamento">Orçamento</a></li>
			<li><a href="#" title="Como Chegar">Como Chegar</a></li>
			<li><a href="#" title="Fale Conosco">Fale Conosco</a></li>
			<li><a href="#" title="Trabalhe Conosco">Trabalhe Conosco</a></li>
			<li class="last"><a href="#" title="Atendimento e Vendas">Atendimento e Vendas</a></li>
		</ul>
		
		<img src="images/iso-9001.gif" alt="Certificado ISO 9001" title="Certificado ISO 9001" class="iso" />
		<p>
		<strong>Alpex Produtos Extrudados:</strong> <br />Rua Guamiranga, 1396 São Paulo/SP <br />(11) 2215-8844
		<br class="clear" /><br />
		<strong>Alpex Produtos Acabados:</strong> <br /> Rua Platina, 60 São Caetano do Sul/SP <br />(11) 4223-4180
		</p>
		
		<br class="clear" />		
		
	</div>	
</div> <!-- /footer !-->