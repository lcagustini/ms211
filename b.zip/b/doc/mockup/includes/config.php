<?php
	$url = basename($_SERVER['PHP_SELF']);
	define("SITE_URL","http://www.alpex.com.br/");
?>