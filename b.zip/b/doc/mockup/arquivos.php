<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Notícias</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" /> 
<link rel="stylesheet" type="text/css" href="css/jquery.ui.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript">
$(function() {
	$("#datepicker").datepicker();
});
</script>
	
</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li><a href="#" title="Últimas Notícias">Últimas Notícias</a></li>
		<li class="ativo"><a href="#" title="Arquivos de Notícias">Arquivos de Notícias</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		<div class="collapse"> 
			<div class="accordionButton"><h3>Calendário</h3><span class="visitado"></span></div>
				<div class="accordionContent">
					<div id="datepicker"></div>
				</div>
			<div class="accordionSemButton"><a href="" title="Saiba Mais">Saiba Mais</a><span></span></div>
			<div class="accordionButton"><h3>Envie para um amigo</h3><span></span></div>
				<div class="accordionContent">
					<div class="envie">
						<ul>
							<li>
								<input type="text" id="nome" name="nome" value="digite seu nome" onfocus="if (this.value == 'digite seu nome') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu nome';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="seu-email" name="seu-email" value="digite seu email" onfocus="if (this.value == 'digite seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu email';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="email-amigo" name="email-amigo" value="insira o email do seu amigo" onfocus="if (this.value == 'insira o email do seu amigo') {this.value = '';}" onblur="if (this.value == '') {this.value = 'insira o email do seu amigo';}" class="text pequeno">
							</li>			
						</ul>
						
						<a class="button-blue" href="#" title="enviar agora">enviar agora</a>
						<a class="button-blue" href="#" title="continuar navegando">continuar navegando</a>
						
						<br class="clear" />
						
					</div> <!-- /envie -->
				</div>
		</div> <!-- /collapse -->
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Notícias">Notícias</a></li>
		<li class="last"><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
	</ul>
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	<div class="arquivo">
		<div class="date">10 de janeiro de 2012</div>
		<h4>Sustentabilidade</h4>
		<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil...</p>
		<a class="mais" href="#" title="Sustentabilidade">+</a>
	</div>
	
	<br />
	 
	
	
	
	<br class="clear" />
	
	<a class="anterior" href="#" title="Anterior">anterior</a>
		<span class="barra">/</span>
	<a class="proxima" href="#" title="Próxima">próxima</a>
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
