<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="alpex, alumínio, extrusão, extrusão de alumínio, perfil extrudado, perfil de alumínio, solução em alumínio, indústria moveleira, kit Box, solução personalizada, produto em alumínio, cotação dólar, cotação LME, LME alumínio, persianas, esquadrias, tubos, cantoneiras, perfis de alumínio, trilho, janelas em alumínio, divisórias, kit engenharia, usinados, mobiliário urbano, puxadores, prateleiras, calceiros, acessórios e arremates." />
<meta name="description" content="Alpex Alumínio atua no desenvolvimento de soluções em perfis extrudados de alumínio e de projetos especiais, feitos sob medida." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script> 
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	//Forms
	$("select#tipo, input#email, textarea").uniform();
	
	//Boxes
	$('#boxes ul li').hover(function(){ 
		$(this).addClass('hover'); 
		$(this).find('.imagem').addClass('hover'); 
			},function(){ 
		$(this).removeClass('hover'); 
		$(this).find('.imagem').removeClass('hover'); 
	});
	
	//Boxes
	$("#boxes ul li").click(function(){
    		window.location=$(this).find("a").attr("href");return false;
	}); 
});
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="slider">
	<object width="100%" height="570" type="application/x-shockwave-flash" data="flash/banner.swf" title="Produtos em Destaque" >
		<param name="movie" value="flash/banner.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /slider -->

<div id="boxes">
	<ul>
		<li>
			<div class="imagem">
				<img src="images/sustentabilidade.jpg" alt="Sustentabilidade" title="Sustentabilidade" />
				<h4>Sustentabilidade</h4>
			</div>
			<div class="texto">
				<p>Pellentesque viverra turpis sit amet ipsum euismod nec consectetur orci convallis. In nec tortor nunc, a accumsan nibh...</p>
				<a href="sustentabilidade.php" title="Sustentabilidade">+</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<img src="images/produtos-extrudados.jpg" alt="Produtos Extrutados" title="Produtos Extrutados" />
				<h4>Produtos Extrutados</h4>
			</div>
			<div class="texto">
				<p>Pellentesque viverra turpis sit amet ipsum euismod nec consectetur orci convallis. In nec tortor nunc, a accumsan nibh...</p>
				<a href="produtos-extrudados.php" title="Produtos Extrutados">+</a>
			</div>
		</li>
		<li>
			<div class="imagem">
				<img src="images/produtos-acabados.jpg" alt="Produtos Acabados" title="Produtos Acabados" />
				<h4>Produtos Acabados</h4>
			</div>
			<div class="texto">
				<p>Pellentesque viverra turpis sit amet ipsum euismod nec consectetur orci convallis. In nec tortor nunc, a accumsan nibh...</p>
				<a href="produtos-acabados.php" title="Produtos Acabados">+</a>
			</div>
		</li>
	</ul>
</div> <!-- /boxes !-->

<div id="shortcus">
	<ul>
		<li id="newsletters">
			<h5>newsletters</h5>			
			<form id="news" method="get" action="">
				<select id="tipo">
					<option>Selecione o tipo de newsletter</option>
					<option>Sustentabilidade</option>
					<option>Produtos Extrudados</option>
					<option>Produtos Acabados</option>
				</select>
				<input class="home" type="text" name="email" id="email" value="Digite aqui o seu email" onfocus="if (this.value == 'Digite aqui o seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Digite aqui o seu email';}" />
				<input type="submit" value="Assinar" name="assinar" id="assinar" />
			</form>
		</li>
		<li id="cotacao">
			<h5>cotação LME</h5>
			<div class="cotacoes">
				<dl>
					<dt>Dollar</dt>
					<dd>1,8486</dd>
					<dt>Alumínio</dt>
					<dd>1.977,00</dd>
				</dl>
				<a href="#" title="Cotações Anteriores">Cotações anteriores</a>
			</div>
		</li>
		<li id="downloads">
			<h5>download dos catálogos</h5>
			<p>Pellentesque viverra turpis sit amet ipsum euismod nec consectetur orci convallis</p>
			<span></span>
			<ol>
				<li><a href="#" title="Fazer download">Fazer download</a></li>
				<li class="last"><a href="#" title="Clique aqui para solicitar o catalogo">Clique aqui para solicitar o catalogo</a></li>
			</ol>
		</li>
	</ul>
</div> <!-- /shortcuts !-->

<?php include ('includes/footer.php'); ?>

</body>
</html>
