<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<title>Alpex – Metatags</title>

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image">
	<object width="100%" height="330" type="application/x-shockwave-flash" data="flash/sustentabilidade.swf" title="Sustentabilidade">
		<param name="movie" value="flash/sustentabilidade.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<?php include ('includes/submenu-sobre.php'); ?>

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Sobre a Alpex">Sobre a Alpex</a></li>
		<li class="last"><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
	</ul>
	
	<h4>Sustentabilidade</h4>
	<textarea class="metatags">
<title>Alpex – Sustentabilidade | Responsabilidade Social e Ambiental</title>
<meta name="keywords" content="alpex, alumínio, sustentabilidade, responsabilidade, social, ambiental, reciclagem, alumínio, sustentável" />
<meta name="description" content="A Alpex Alumínio tem o compromisso de manter seu desenvolvimento de maneira sustentável, respeitando o meio ambiente e as pessoas." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>História</h4>
	<textarea class="metatags">
<title>Alpex – Sobre a Alpex | História - Soluções em Alumínio, Missão, Visão e Valores</title>
<meta name="keywords" content="alpex, alumínio, missão, visão, valores, produtos, extrudados, acabados, sistemas" />
<meta name="description" content="Alpex Alumínio atua no desenvolvimento de soluções em perfis extrudados de alumínio e de projetos especiais, feitos sob medida." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>Unidades</h4>
	<textarea class="metatags">
<title>Alpex – Sobre a Alpex | Unidades – Produtos Extrudados e Produtos Acabados</title>
<meta name="keywords" content="alpex, alumínio, unidades, produtos, extrudados, acabados, tecnologia, profissionais, negócios" />
<meta name="description" content="A Alpex é formada por duas unidades de negócios que contam com a mais alta tecnologia, profissionais capacitados e compromissados com o projeto de cada cliente." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>Sobre o Alumínio</h4>
	<textarea class="metatags">
<title>Alpex – Sobre o Alumínio | Metal que faz a diferença nos negócios no Dia-a-Dia</title>
<meta name="keywords" content="alpex, alumínio, bauxita, metal, reciclagem, matéria, prima, indispensável, qualidade, segurança" />
<meta name="description" content="O alumínio é a matéria prima indispensável para a Alpex Alumínio e uma ótima opção para quem deseja projetar qualquer produto com qualidade e segurança." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>Certificados ISO 9001</h4>
	<textarea class="metatags">
<title></title>
<meta name="keywords" content="alpex, alumínio, certificado, certificação, iso, 9001, excelência, qualidade, atendimento, serviços, aprovação" />
<meta name="description" content="A Alpex recebeu a aprovação e a certificação da excelência na qualidade, no atendimento e na prestação de serviços para suas duas unidades de negócios: Alpex Produtos Extrudados (APE) e Alpex Produtos Acabados (APA). " />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>Produtos Extrudados</h4>
	<textarea class="metatags">
<title>Alpex – Produtos Extrudados | Perfis de Alumínio em Barra e Sob Medida</title>
<meta name="keywords" content="alpex, alumínio, produtos, extrudados, perfil, extrudado, barra, segmentos, aplicação, variados" />
<meta name="description" content="Alpex Produtos Extrudados fornece perfil de alumínio extrudado para aplicação nos mais variados segmentos." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>Produtos Acabados</h4>
	<textarea class="metatags">
<title>Alpex – Produtos Acabados |Puxadores, Kit Box, Trilhos, Prateleiras, Cabideiros</title>
<meta name="keywords" content="alpex, produtos, acabados, fornece, porta, alumínio, usinados, indústria, moveleira, kit, box, engenharia, mobiliário, urbano, corporativo." />
<meta name="description" content="Alpex, alumínio, Alpex Produtos Acabados, projeto sob medida, solução em alumínio, indústria moveleira, kit Box, kit engenharia, Box para banheiro, móveis cozinha." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<h4>Lançamentos</h4>
	<textarea class="metatags">
<title>Alpex – Produtos | Lançamentos Produtos Acabados e Produtos Extrudados</title>
<meta name="keywords" content="alpex, produtos, acabados, fornece, lançamentos, linhas" />
<meta name="description" content="Conheça os lançamentos da Alpex clicando em uma das linhas encontradas nessa página." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />
	</textarea>
	
	<br class="clear" />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
