<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Sustentabilidade | Responsabilidade Social e Ambiental</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="alpex, alumínio, sustentabilidade, responsabilidade, social, ambiental, reciclagem, alumínio, sustentável" />
<meta name="description" content="A Alpex Alumínio tem o compromisso de manter seu desenvolvimento de maneira sustentável, respeitando o meio ambiente e as pessoas." />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image">
	<object width="100%" height="330" type="application/x-shockwave-flash" data="flash/sustentabilidade.swf" title="Sustentabilidade">
		<param name="movie" value="flash/sustentabilidade.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<?php include ('includes/submenu-sobre.php'); ?>

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Sobre a Alpex">Sobre a Alpex</a></li>
		<li class="last"><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
	</ul>
	
	<h4>Sustentabilidade</h4>
	<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil, a Alpex é uma empresa que se preocupa com a sustentabilidade e a responsabilidade social e ambiental.</p>

	<p>A indústria do alumínio tem o compromisso de manter seu desenvolvimento de maneira sustentável, respeitando o meio ambiente e as pessoas envolvidas em seu negócio: clientes, funcionários e as comunidades em que atua.</p>

	<p>Investir em programas de preservação, Gerar benefícios sociais aos colaboradores as comunidades é fundamental para que o alumínio continue presente em qualquer projeto, hoje e no futuro.</p>

	<p>Produtos feitos com alumínio são duráveis, resistentes à corrosão e não exigem manutenção intensa, ou seja, têm uma vida útil bastante elevada, o que contribui com a diminuição de lixo e a emissão de gases do efeito estufa. Além disso, o alumínio é versátil e 100% reciclável, tornando-se indispensável na construção dos modernos edifícios verdes.</p>

	<p>Utilizar o alumínio de maneira racional e sustentável é também um compromisso da Alpex.</p>
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
