<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Como Chegar</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script> 
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	//Forms
	$("select#area, input.text, textarea").uniform(); 
}); 
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li><a href="sac.php" title="SAC">SAC</a></li>
		<li><a href="orcamento.php" title="Orçamento">Orçamento</a></li> 
		<li class="ativo"><a href="como-chegar.php" title="Como Chegar">Como Chegar</a></li> 
		<li><a href="fale-conosco.php" title="Fale Conosco">Fale Conosco</a></li> 
		<li><a href="trabalhe-conosco.php" title="Trabalhe Conosco">Trabalhe Conosco</a></li> 
		<li><a href="atendimento.php" title="Atendimento e Vendas">Atendimento</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description" class="fale-conosco">
	
	<ul class="breadcrumb">		
		<li class="first"><a href="#" title="Contato">Contato</a></li>
		<li class="last"><a href="#" title="Como Chegar">Como Chegar</a></li>
	</ul>
	
	<h4>Como Chegar</h4>
	<p></p> 
	
	<div class="localizacao">
		<h5>Alpex Produtos Extrudados</h5>
		<p>Rua Guamiranga, 1396 São Paulo/SP (11) 2215-8844</p>
		<p class="frame">
		<iframe width="550" scrolling="no" height="350" frameborder="0" src="http://maps.google.com.br/maps?f=q&amp;source=s_q&amp;hl=pt-BR&amp;geocode=&amp;q=Alpex+Aluminio&amp;sll=6.870947,-88.73776&amp;sspn=57.497533,107.138672&amp;ie=UTF8&amp;hq=Alpex+Aluminio&amp;hnear=&amp;cid=8560558678972113976&amp;ll=-23.587272,-46.577911&amp;spn=0.021002,0.035706&amp;z=14&amp;iwloc=A&amp;output=embed" marginwidth="0" marginheight="0"></iframe>
		<a href="http://maps.google.com.br/maps?f=q&amp;source=s_q&amp;hl=pt-BR&amp;geocode=&amp;q=Alpex+Aluminio&amp;sll=6.870947,-88.73776&amp;sspn=57.497533,107.138672&amp;ie=UTF8&amp;hq=Alpex+Aluminio&amp;hnear=&amp;cid=8560558678972113976&amp;ll=-23.587272,-46.577911&amp;spn=0.021002,0.035706&amp;z=14&amp;iwloc=A&amp;output=embed" title="Clique aqui para ampliar o mapa!" target="_blank">Clique aqui para ampliar o mapa!</a>
		</p>
		
		<h5>Alpex Produtos Acabados</h5>
		<p>Rua Platina, 60 São Caetano do Sul/SP (11) 4223-4180</p>
		<p class="frame">
		<iframe width="550" scrolling="no" height="350" frameborder="0" src="http://maps.google.com.br/maps?f=q&amp;source=s_q&amp;hl=pt-BR&amp;geocode=&amp;q=Rua+Platina,+60+S%C3%A3o+Caetano+do+Sul%2FSP+(11)+4226-7556&amp;sll=-23.59795,-46.582932&amp;sspn=0.013056,0.026157&amp;ie=UTF8&amp;hq=&amp;hnear=R.+Platina,+60+-+Prosperidade,+S%C3%A3o+Caetano+do+Sul+-+S%C3%A3o+Paulo,+09550-630&amp;ll=-23.599857,-46.541948&amp;spn=0.021,0.03562&amp;z=14&amp;iwloc=A&amp;output=embed" marginwidth="0" marginheight="0"></iframe>
		<a href="http://maps.google.com.br/maps?f=q&amp;source=s_q&amp;hl=pt-BR&amp;geocode=&amp;q=Rua+Platina,+60+S%C3%A3o+Caetano+do+Sul%2FSP+(11)+4226-7556&amp;sll=-23.59795,-46.582932&amp;sspn=0.013056,0.026157&amp;ie=UTF8&amp;hq=&amp;hnear=R.+Platina,+60+-+Prosperidade,+S%C3%A3o+Caetano+do+Sul+-+S%C3%A3o+Paulo,+09550-630&amp;ll=-23.599857,-46.541948&amp;spn=0.021,0.03562&amp;z=14&amp;iwloc=A&amp;output=embed" title="Clique aqui para ampliar o mapa!" target="_blank">Clique aqui para ampliar o mapa!</a>
		</p>
	</div>
	
	<br class="clear" /> 
	<br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div> 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
