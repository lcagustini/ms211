<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Notícias | Sustentabilidade</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" /> 
<link rel="stylesheet" type="text/css" href="css/jquery.ui.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<!--
<script type="text/javascript" src="js/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="js/jquery.ui.datepicker.js"></script> 
<script type="text/javascript">
$(function() {
	$("#datepicker").datepicker();
});
</script>
-->
	
</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li class="ativo"><a href="#" title="Últimas Notícias">Últimas Notícias</a></li>
		<li><a href="#" title="Arquivos de Notícias">Arquivos de Notícias</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		<div class="collapse"> 
			<div class="accordionSemButton"><a href="" title="Saiba Mais">Saiba Mais</a><span></span></div>
			<div class="accordionButton"><h3>Envie para um amigo</h3><span></span></div>
				<div class="accordionContent">
					<div class="envie">
						<ul>
							<li>
								<input type="text" id="nome" name="nome" value="digite seu nome" onfocus="if (this.value == 'digite seu nome') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu nome';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="seu-email" name="seu-email" value="digite seu email" onfocus="if (this.value == 'digite seu email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'digite seu email';}" class="text pequeno">
							</li>
							<li>
								<input type="text" id="email-amigo" name="email-amigo" value="insira o email do seu amigo" onfocus="if (this.value == 'insira o email do seu amigo') {this.value = '';}" onblur="if (this.value == '') {this.value = 'insira o email do seu amigo';}" class="text pequeno">
							</li>			
						</ul>
						
						<a class="button-blue" href="#" title="enviar agora">enviar agora</a>
						<a class="button-blue" href="#" title="continuar navegando">continuar navegando</a>
						
						<br class="clear" />
						
					</div> <!-- /envie -->
				</div>
		</div> <!-- /collapse -->
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Notícias">Notícias</a></li>
		<li class="last"><a href="#" title="Sustentabilidade">Sustentabilidade</a></li>
	</ul>
	
	
	<h4>Sustentabilidade</h4>
	<div class="date black">A Alpex sabe como cuidar do meio ambiente</div>
	<br class="clear" />
	
	<p>Para que produtos de qualidade continuem chegando às casas, indústrias e empresas espalhadas por todo o Brasil, a Alpex é uma empresa que se preocupa com a sustentabilidade e a responsabilidade social e ambiental.</p>
	
	<img src="images/foto.jpg" alt="Sustentabilidade" title="Sustentabilidade" />
	
	<p>A indústria do alumínio tem o compromisso de manter seu desenvolvimento de maneira sustentável, respeitando o meio ambiente e as pessoas envolvidas em seu negócio: clientes, funcionários e as comunidades em que atua.</p>

	<p>Produtos feitos com alumínio são duráveis, resistentes à corrosão e não exigem manutenção intensa, ou seja, têm uma vida útil bastante elevada, o que contribui com a diminuição de lixo e a emissão de gases do efeito estufa. Além disso, o alumínio é versátil e 100% reciclável, tornando-se indispensável na construção dos modernos edifícios verdes.</p>

	<p>Utilizar o alumínio de maneira racional e sustentável é também um compromisso da Alpex.</p>
	
	<br class="clear" />
	
	<p class="black">
		<strong>Fonte:</strong> <i>Alpex</i><br />
		<strong>Data:</strong> <i>10 de janeiro de 2012</i>
	</p>
	
	<br class="clear" />
	
	<a class="anterior" href="#" title="Anterior">anterior</a>
		<span class="barra">/</span>
	<a class="proxima" href="#" title="Próxima">próxima</a>
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div>
	
	<br class="clear" />
	
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
