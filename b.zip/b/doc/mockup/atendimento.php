<?php include("includes/config.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Alpex – Atendimentos e Vendas</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta http-equiv="Content-Language" content="pt-br" />
<meta http-equiv="Window-target" content="_self" /> 
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />

<!-- ~~~~~~~~~~ Metatags ~~~~~~~~~~  !-->
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="robots" content="index, all" />
<meta name="author" content="Imaginera" />

<!-- ~~~~~~~~~~ Favicon ~~~~~~~~~~  !-->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">

<!-- ~~~~~~~~~~~ Styles ~~~~~~~~~~~  !-->
<link rel="stylesheet" type="text/css" href="css/resets.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/uniform.css" media="all" />

<!-- ~~~~~~~~~~~ Scripts ~~~~~~~~~~  !-->
<script type="text/javascript" src="js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="js/cufon.js" charset="utf-8"></script>
<script type="text/javascript" src="js/frutiger.js" charset="utf-8"></script>
<script type="text/javascript" src="js/uniform.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/collapse.js" charset="utf-8"></script>
<script type="text/javascript" src="js/jquery.limit.js" charset="utf-8"></script>
<script type="text/javascript" src="js/config.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	//Forms
	$("select#area, select#assunto, input.text, textarea").uniform();
	$('#mensagem').limit('1024','#restantes span');
}); 
</script>

</head>

<body>

<?php include ('includes/header.php'); ?>

<div id="image" class="no-image">
	<object width="100%" height="260" type="application/x-shockwave-flash" data="flash/sem-imagem.swf" title="">
		<param name="movie" value="flash/sem-imagem.swf" />
		<param name="wmode" value="transparent"></param>
		<param name="allowFullScreen" value="false">
	</object>
</div> <!-- /image -->

<div id="submenu">
	<ul> 
		<li><a href="sac.php" title="SAC">SAC</a></li>
		<li><a href="orcamento.php" title="Orçamento">Orçamento</a></li> 
		<li><a href="como-chegar.php" title="Como Chegar">Como Chegar</a></li> 
		<li><a href="fale-conosco.php" title="Fale Conosco">Fale Conosco</a></li> 
		<li><a href="trabalhe-conosco.php" title="Trabalhe Conosco">Trabalhe Conosco</a></li> 
		<li class="ativo"><a href="atendimento.php" title="Atendimento e Vendas">Atendimento</a></li> 
	</ul>
</div> <!-- /submenu-->

<div id="page">
	<div id="categories">
		<?php include ('includes/sidebar-paginas.php'); ?>
	</div>
	
	<div id="description">
	
	<ul class="breadcrumb">
		<li class="first"><a href="#" title="Contato">Contato</a></li>
		<li class="last"><a href="#" title="Atendimentos e Vendas">Atendimentos e Vendas</a></li>
	</ul>
	
	<h4>Atendimentos e Vendas</h4>
	<p>De Segunda à Sexta das 8h às 18h.</p>
	<div class="vendas">
		<h5>Alpex Produtos Extrudados</h5>
			<ul>
				<li>Aline Andrade</li>
				<li>Cristina Arrais</li>
				<li>Douglas de Oliveira</li>
				<li>Eliana Silva</li>
				<li>Fernanda Ferreira</li>
				<li>Jaqueline Contelli</li>
				<li>Néia Monteiro</li>
				<li>Rogério Leite</li>
				<li>Rosangela Amaral</li>
				<li>Tarquínio Durante</li>
				<li>Wagner Sales</li>
				<li>Willians de Carvalho</li>
			</ul>
			<p>E-mail: <a href="mailto:aluminio@alpex.com.br" title="">aluminio@alpex.com.br</a></p>	 
		<h5>Alpex Produtos Extrudados</h5>
			<ul>
				<li>Aracele Zanoni</li>
				<li>Claudiana Figueiredo</li>
				<li>Fernando Bianchim</li>
				<li>Flavia Paes</li>
				<li>Hélio Donizeti Batista</li>
				<li>Tatiana Strublic</li>
				<li>Valéria Marini</li>
			</ul>
			<p>E-mail: <a href="mailto:vendas.apa@alpex.com.br" title="">vendas.apa@alpex.com.br</a></p>	
	</div>
	
	<br /><br /><br />
	
	<a class="voltar" href="javascript:history.back();" title="Voltar">voltar</a>
	
	</div> 
	<br class="clear" /> 
</div> <!-- /page -->

<?php include ('includes/footer.php'); ?>

</body>
</html>
