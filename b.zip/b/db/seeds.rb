# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ :name => 'Chicago' }, { :name => 'Copenhagen' }])
#   Mayor.create(:name => 'Emanuel', :city => cities.first)

# Usuários e Permissões
AppModule.create(:name => "Categoria APA", :subject_class => Category.model_name, :subject_condition => "{:category_type => CategoryType::APA}")
AppModule.create(:name => "Categoria APE", :subject_class => Category.model_name, :subject_condition => "{:category_type => CategoryType::APE}")

AppModule.create(:name => "Produtos APA", :subject_class => Product.model_name, :subject_condition => "{:product_type => ProductType::APA}")

AppModule.create(:name => "Produtos APA - Coleções", :subject_class => ProductCollection.model_name)
AppModule.create(:name => "Produtos APA - Coleções - Associação", :subject_class => ProductAssociation.model_name)

AppModule.create(:name => "Produtos APE", :subject_class => Product.model_name, :subject_condition => "{:product_type => ProductType::APE}")

AppModule.create(:name => "Produtos - Fotos de Imagem de Linha", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::LINE}")
AppModule.create(:name => "Produtos - Fotos de Cores Disponíveis", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::COLOR}")
AppModule.create(:name => "Produtos - Fotos de Aplicações", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::APPLICATION}")
AppModule.create(:name => "Produtos - Fotos de Desenho 3D", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::TD}")
AppModule.create(:name => "Produtos - Fotos de Desenho Técnico", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::TECH}")
AppModule.create(:name => "Produtos - Fotos de Desenho Técnico Detalhado", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::TECH_DETAIL}")
AppModule.create(:name => "Produtos - Fotos de Modelos Disponíveis", :subject_class => ProductPhoto.model_name, :subject_condition => "{:photo_type => ProductPhotoType::MODEL}")

AppModule.create(:name => "Páginas", :subject_class => Page.model_name)
AppModule.create(:name => "Notícias", :subject_class => News.model_name)

AppModule.create(:name => "Eventos e Galerias", :subject_class => Event.model_name)
AppModule.create(:name => "Eventos e Galerias - Fotos", :subject_class => EventPhoto.model_name)

AppModule.create(:name => "Cotações LME", :subject_class => Lme.model_name)
AppModule.create(:name => "Sustentabilidade", :subject_class => Sustainability.model_name)
AppModule.create(:name => "Currículos", :subject_class => Resume.model_name)
AppModule.create(:name => "Contatos", :subject_class => SiteContact.model_name)
AppModule.create(:name => "Newsletter", :subject_class => Newsletter.model_name)
AppModule.create(:name => "Usuários e Permissões", :subject_class => User.model_name)

User.create(:email => "admin@alpex.com.br", :password => "123456", :password_confirmation => "123456")

u = User.find_by_email("admin@alpex.com.br")

AppModule.all.each do |app_module|
  u.permissions.create :app_module => app_module, :can_read => true, :can_update => true, :can_destroy => true, :can_create => true
end

# Páginas

Page.create(:title => 'História', :content => 'História...', :template => 0)
Page.create(:title => 'Unidades', :content => 'Unidades...', :template => 0)
Page.create(:title => 'Sustentabilidade', :content => 'Sustentabilidade...', :template => 0)
Page.create(:title => 'Sobre o Alumínio', :content => 'Sobre o Alumínio...', :template => 0)
Page.create(:title => 'Certificados ISO', :content => 'Certificados ISO...', :template => 0)
Page.create(:title => 'Links Úteis', :content => 'Links Úteis...', :template => 0)
Page.create(:title => 'Assessoria de Imprensa', :content => 'Assessoria de Imprensa...', :template => 1)
Page.create(:title => 'Orçamento', :content => 'Orçamento...', :template => 2)
Page.create(:title => 'Como Chegar', :content => 'Como Chegar...', :template => 2)
Page.create(:title => 'Atendimento e Vendas', :content => 'Atendimento e Vendas...', :template => 2)

