class AddUnitToSiteContact < ActiveRecord::Migration
  def change
    add_column :site_contacts, :unit, :integer
  end
end
