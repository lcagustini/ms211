class AddContactTypeToSiteContacts < ActiveRecord::Migration
  def change
    add_column :site_contacts, :contact_type, :integer

  end
end
