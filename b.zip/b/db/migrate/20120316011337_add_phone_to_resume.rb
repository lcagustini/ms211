class AddPhoneToResume < ActiveRecord::Migration
  def change
    add_column :resumes, :phone, :string

  end
end
