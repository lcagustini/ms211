class AddSubtitleToProductPhoto < ActiveRecord::Migration
  def change
    add_column :product_photos, :subtitle, :string

  end
end
