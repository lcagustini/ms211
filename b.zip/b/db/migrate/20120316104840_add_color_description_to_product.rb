class AddColorDescriptionToProduct < ActiveRecord::Migration
  def change
    add_column :products, :color_description, :text

  end
end
