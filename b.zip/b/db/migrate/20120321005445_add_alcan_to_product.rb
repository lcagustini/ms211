class AddAlcanToProduct < ActiveRecord::Migration
  def change
    add_column :products, :alcan, :string

  end
end
