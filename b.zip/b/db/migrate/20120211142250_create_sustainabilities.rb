class CreateSustainabilities < ActiveRecord::Migration
  def change
    create_table :sustainabilities do |t|
      t.string :phone
      t.string :site
      t.text :description

      t.timestamps
    end
  end
end
