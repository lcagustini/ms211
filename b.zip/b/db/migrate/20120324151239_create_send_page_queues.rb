class CreateSendPageQueues < ActiveRecord::Migration
  def change
    create_table :send_page_queues do |t|
      t.string :session_id
      t.string :url
      t.string :title

      t.timestamps
    end
  end
end
