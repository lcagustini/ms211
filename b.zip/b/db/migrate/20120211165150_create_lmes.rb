class CreateLmes < ActiveRecord::Migration
  def change
    create_table :lmes do |t|
      t.decimal :dollar_price, :precision => 8, :scale => 4
      t.decimal :aluminum_price, :precision => 8, :scale => 2
      t.date :quotation_date

      t.timestamps
    end
  end
end
