class AddPermissionDetailsToPermission < ActiveRecord::Migration
  def change
    add_column :permissions, :can_read, :boolean
    add_column :permissions, :can_create, :boolean
    add_column :permissions, :can_update, :boolean
    add_column :permissions, :can_destroy, :boolean
  end
end
