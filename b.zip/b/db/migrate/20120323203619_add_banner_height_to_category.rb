class AddBannerHeightToCategory < ActiveRecord::Migration
  def change
    add_column :categories, :banner_height, :integer

  end
end
