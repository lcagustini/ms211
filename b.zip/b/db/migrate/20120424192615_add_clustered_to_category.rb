class AddClusteredToCategory < ActiveRecord::Migration
  def change
    add_column :categories, :clustered, :boolean
  end
end
