class CreateEvents < ActiveRecord::Migration
  def change
    create_table :events do |t|
      t.string :name
      t.string :place
      t.string :url
      t.date :event_at
      t.integer :event_type

      t.timestamps
    end
  end
end
