class CreateNews < ActiveRecord::Migration
  def change
    create_table :news do |t|
      t.string :title
      t.string :subtitle
      t.text :content
      t.date :event_at
      t.string :slug

      t.timestamps
    end
    add_index :news, :slug, :unique => true
  end
end
