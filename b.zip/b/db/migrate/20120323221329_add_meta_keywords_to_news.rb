class AddMetaKeywordsToNews < ActiveRecord::Migration
  def change
    add_column :news, :meta_keywords, :string

  end
end
