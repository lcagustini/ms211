class AddBannerHeightToProduct < ActiveRecord::Migration
  def change
    add_column :products, :banner_height, :integer

  end
end
