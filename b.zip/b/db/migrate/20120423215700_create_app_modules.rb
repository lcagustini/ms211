class CreateAppModules < ActiveRecord::Migration
  def change
    create_table :app_modules do |t|
      t.string :name
      t.string :subject_class

      t.timestamps
    end
  end
end
