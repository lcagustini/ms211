class AddSubjectToSiteContact < ActiveRecord::Migration
  def change
    add_column :site_contacts, :subject, :string

  end
end
