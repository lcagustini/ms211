class CreateProductAssociations < ActiveRecord::Migration
  def change
    create_table :product_associations do |t|
      t.references :product_collection
      t.references :product

      t.timestamps
    end
    add_index :product_associations, :product_collection_id
    add_index :product_associations, :product_id
  end
end
