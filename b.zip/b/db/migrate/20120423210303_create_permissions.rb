class CreatePermissions < ActiveRecord::Migration
  def change
    create_table :permissions do |t|
      t.references :user
      t.references :app_module

      t.timestamps
    end
    add_index :permissions, :user_id
    add_index :permissions, :app_module_id
  end
end
