class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.references :category
      t.string :name
      t.string :code
      t.date :release_date
      t.integer :order_to
      t.string :color
      t.text :description
      t.text :features
      t.text :accessories
      t.string :dimension
      t.text :colors_table
      t.text :features_table
      t.text :dimensions_table
      t.text :sizes_table
      t.integer :product_type
      t.integer :status

      t.timestamps
    end
    add_index :products, :category_id
  end
end
