class AddEventEndAtToEvents < ActiveRecord::Migration
  def change
    add_column :events, :event_end_at, :date

  end
end
