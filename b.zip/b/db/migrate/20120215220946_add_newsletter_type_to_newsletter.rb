class AddNewsletterTypeToNewsletter < ActiveRecord::Migration
  def change
    add_column :newsletters, :newsletter_type, :integer

  end
end
