class AddAssociatedProductIdToProductAssociation < ActiveRecord::Migration
  def change
    add_column :product_associations, :associated_product_id, :string
    add_index :product_associations, :associated_product_id
  end
end
