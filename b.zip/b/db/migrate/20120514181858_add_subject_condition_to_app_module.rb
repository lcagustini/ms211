class AddSubjectConditionToAppModule < ActiveRecord::Migration
  def change
    add_column :app_modules, :subject_condition, :string
  end
end
