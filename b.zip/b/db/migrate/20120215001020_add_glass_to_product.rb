class AddGlassToProduct < ActiveRecord::Migration
  def change
    add_column :products, :glass, :text

  end
end
