class AddInterestAreaToResumes < ActiveRecord::Migration
  def change
    add_column :resumes, :interest_area, :integer

  end
end
