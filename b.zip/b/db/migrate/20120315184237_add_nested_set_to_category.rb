class AddNestedSetToCategory < ActiveRecord::Migration
  def up
    add_column :categories, :parent_id, :integer
    add_column :categories, :lft, :integer
    add_column :categories, :rgt, :integer
    add_column :categories, :depth, :integer
    
    remove_column :categories, :category_id

    add_index :categories, :parent_id
  end

  def down
    remove_column :categories, :parent_id, :integer
    remove_column :categories, :lft, :integer
    remove_column :categories, :rgt, :integer
    remove_column :categories, :depth, :integer
    
    add_column :categories, :category_id, :integer

    remove_index :categories, :parent_id
  end
end
