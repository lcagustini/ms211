class AddOperatingAreaToResumes < ActiveRecord::Migration
  def change
    add_column :resumes, :operating_area, :string

  end
end
