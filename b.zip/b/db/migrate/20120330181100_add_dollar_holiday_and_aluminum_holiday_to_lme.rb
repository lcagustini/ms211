class AddDollarHolidayAndAluminumHolidayToLme < ActiveRecord::Migration
  def change
    add_column :lmes, :dollar_holiday, :boolean

    add_column :lmes, :aluminum_holiday, :boolean

  end
end
