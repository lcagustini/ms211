class CreateSiteContacts < ActiveRecord::Migration
  def change
    create_table :site_contacts do |t|
      t.string :department_sent
      t.string :name
      t.string :organization
      t.string :email
      t.string :phone
      t.text :message

      t.timestamps
    end
  end
end
