class AddNameToProductPhoto < ActiveRecord::Migration
  def change
    add_column :product_photos, :name, :string

  end
end
