class AddTitleToSustainability < ActiveRecord::Migration
  def change
    add_column :sustainabilities, :title, :string

  end
end
