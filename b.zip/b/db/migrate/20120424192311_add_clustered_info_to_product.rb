class AddClusteredInfoToProduct < ActiveRecord::Migration
  def change
    add_column :products, :mm_a, :string
    add_column :products, :mm_b, :string
    add_column :products, :mm_c, :string
    add_column :products, :inch_a, :string
    add_column :products, :inch_b, :string
    add_column :products, :inch_c, :string
  end
end
