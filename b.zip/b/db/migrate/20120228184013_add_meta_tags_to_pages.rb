class AddMetaTagsToPages < ActiveRecord::Migration
  def change
    add_column :pages, :meta_keywords, :string

    add_column :pages, :meta_description, :string

    add_column :pages, :meta_title, :string

  end
end
