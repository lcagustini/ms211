class CreateEventPhotos < ActiveRecord::Migration
  def change
    create_table :event_photos do |t|
      t.string :title
      t.string :credits
      t.text :description
      t.integer :order_to
      t.references :event

      t.timestamps
    end
    add_index :event_photos, :event_id
  end
end
