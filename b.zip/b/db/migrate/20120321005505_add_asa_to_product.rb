class AddAsaToProduct < ActiveRecord::Migration
  def change
    add_column :products, :asa, :string

  end
end
