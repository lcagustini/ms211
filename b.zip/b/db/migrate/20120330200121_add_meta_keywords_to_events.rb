class AddMetaKeywordsToEvents < ActiveRecord::Migration
  def change
    add_column :events, :meta_keywords, :string

  end
end
