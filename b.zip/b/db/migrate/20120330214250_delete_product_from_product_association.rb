class DeleteProductFromProductAssociation < ActiveRecord::Migration
  def up
    remove_column :product_associations, :product_id
  end

  def down
    add_column :product_associations, :product_id, :integer
    add_index :product_associations, :product_id
  end
end
