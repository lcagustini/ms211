class AddOrderToToProductPhoto < ActiveRecord::Migration
  def change
    add_column :product_photos, :order_to, :integer

  end
end
