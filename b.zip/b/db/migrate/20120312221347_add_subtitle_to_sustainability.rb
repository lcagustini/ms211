class AddSubtitleToSustainability < ActiveRecord::Migration
  def change
    add_column :sustainabilities, :subtitle, :string

  end
end
