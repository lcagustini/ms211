class AddApeProductsSectionTitleToProduct < ActiveRecord::Migration
  def change
    add_column :products, :ape_products_section_title, :string
  end
end
