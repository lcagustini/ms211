class ChangeDepartmentSentTypeFromSiteContact < ActiveRecord::Migration
  def up
    change_column :site_contacts, :department_sent, :integer, :limit => nil
  end

  def down
    change_column :site_contacts, :department_sent, :string
  end
end
