class AddAlcoaToProduct < ActiveRecord::Migration
  def change
    add_column :products, :alcoa, :string

  end
end
