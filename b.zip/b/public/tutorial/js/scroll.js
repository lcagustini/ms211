$(document).ready(function(){ 
    $('a.subir').click(function(){
        $('html, body').animate({scrollTop:0}, 'slow');
        return false;
    }); 
    
    $('a.item1').click(function(){
        $('html, body').animate({scrollTop:670}, 'slow');
        return false;
    }); 
    
    $('a.item2').click(function(){
        $('html, body').animate({scrollTop:1200}, 'slow');
        return false;
    }); 
    
    $('a.item3').click(function(){
        $('html, body').animate({scrollTop:1500}, 'slow');
        return false;
    }); 
       
});