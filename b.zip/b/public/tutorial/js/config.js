$(document).ready(function(){

	// Scroll
	$('#submenu ul li').bind('click',function(event){
		var $anchor = $(this).find('a');

		$('html, body').stop().animate({
			scrollTop: $($anchor.attr('href')).offset().top
		}, 1000);
		 
		event.preventDefault();
	});
	
	//Breadcrumb
	$('<span>/</span>').appendTo('#page #description ul.breadcrumb li');
	$('#page #description ul.breadcrumb li.last').find('span').remove();
	
	
	//Submenu
	$('<span class="corner left"></span><span class="corner right"></span>').appendTo('#submenu ul');
	
	
	$("#acabados ul li").click(function(){
    		window.location=$(this).find("a").attr("href");
		return false;
	});
	$('#acabados ul li').hover(function(){ 
		$(this).addClass('hover'); 
		$(this).find('.imagem').addClass('hover'); 
			},function(){ 
		$(this).removeClass('hover'); 
		$(this).find('.imagem').removeClass('hover'); 
	}); 
	
	
	
	//Menu             
    $("#header #menu ul li, #page #description .noticia, #page #description .arquivo, #page #description .busca").click(function () {
        window.location = $(this).find("a").attr("href");
        return false;
    }); 
    
    $(".post.sem-imagem").click(function(){
         var thislink = $(this).find("a.blue");
         if ( thislink.attr('target') == '_blank') // if target=_blank then open in a new window
         window.open(thislink.attr("href"));
      else
          window.location=thislink.attr("href");
      return false;
   });

    //Posts com Imagem           
    $("#page #description .post.com-imagem:not(ul)").click(function () {
    	window.location = $(this).find("a.mais").attr("href");
        return false;     
    });
 
	 
});