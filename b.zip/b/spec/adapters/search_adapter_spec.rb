require "spec_helper"
describe SearchAdapter do 
  context "Given which i try make a search" do
    before do
      params = "John doe"
      @category       = SearchAdapter.new("Category name")
      @search         = SearchAdapter.new(params)
      @page           = FactoryGirl.create(:page)
      @news           = FactoryGirl.create(:news)
      @product_active = FactoryGirl.create(:product)
    end
    it "With 'Jhon Doe' in #Page should show a result" do
      @search.page.first.should eql(@page)
    end

    it "With 'Jhon Doe in #News should show a result" do
      @search.news.first.should eql(@news)
    end

    it "With 'Jhon doe' in #category show all products in result" do
      @category.category.first.should eql(@product_active)
    end
    
    it "with 'Jhon Doe in #Product' show a result just in product #active#" do
      @search.product.first.should eql(@product_active)
    end
    
    it "with 'Jhon Doe in #Product' not show a result just in product #unactive#" do
      product_unactive = Product.last
      product_unactive.update_attributes(:status => 0)
      @search.product.first.should be_false
    end  

    it "Count all registers" do
      all_results = @search.page.size + @search.news.size + @search.product.size + @category.product.size
      @search.total_of_results.should eql(all_results)
    end

    it "Merge all response within at results variable" do
      all_results = @search.page + @search.news + @search.product +  @category.product
      @search.results.should eql(all_results)
    end 
  end  
end  
