FactoryGirl.define do
  factory :news do
      title "John Doe"
      subtitle "John Doe"
      content "Something with John Doe"
      event_at "2012-02-11"
      slug "john-doe"
    end
end
