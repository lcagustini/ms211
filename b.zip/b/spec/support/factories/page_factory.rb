FactoryGirl.define do
  factory :page do
      slug "John Doe"
      title "John Doe"
      content "something about John doe"
      template "template with something"
    end
end
