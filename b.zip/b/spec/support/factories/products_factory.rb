FactoryGirl.define do
  factory :category do
      name "Category name"
      status 1
      description "something"
      #category nil
      category_type "1"
  end
  factory :product do
      #association :id, factory: :category, strategy: :build
      category
      name "John Doe"
      code "John doe"
      release_date "2012-02-13"
      order_to 1
      color "MyString"
      description "John doe something "
      features "john doe is one great programer"
      accessories "MyText"
      dimension "MyString"
      colors_table "MyText"
      features_table "MyText"
      dimensions_table "MyText"
      sizes_table "MyText"
      product_type 1
      status 1
      meta_keywords "001, one, two"
  end

end
