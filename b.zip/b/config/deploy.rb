# require 'config/deploy/notifier.rb'
require File.join(File.dirname(__FILE__), 'deploy', 'notifier')
# APP SETTINGS
#Define environment and environment default
set :stages, %w(staging production)
set :default_stage, "production"

require 'capistrano/ext/multistage'
set :application, "alpex-site"

# GIT SETTINGS
set :scm, :git
set :repository,  "git@github.com:68100064000106/alpex.git"
set :branch, "deploy"
set :deploy_via, :remote_cache
set :keep_releases, 5

# NOTIFIERS
set :notify_emails, ["eder.esilva@gmail.com"]

# HOOKS
after 'deploy:update_code' do
  db.symlink
  config.symlink
  newrelic.symlink
  ckeditor_assets.symlink
  bundler.bundle_new_release

  # FIXME Foi desabilitado temporariamente pelo erro de carregamento do CKEditor no IE9 quando compilado.
  # para mais detalhes veja o ticket #697
  #assets.precompile

  deploy.notify
end


namespace :db do
  desc "link database.yml"
  task :symlink do
    run "ln -s #{shared_path}/database.yml #{release_path}/config/database.yml"
  end

  desc "seed database"
  task :seed do
    run "cd #{release_path} && rake db:seed RAILS_ENV=production"
  end
end

namespace :config do
  desc "link site_config.yml"
  task :symlink do
    run "ln -s #{shared_path}/site_config.yml #{release_path}/config/site_config.yml"
  end
end

namespace :newrelic do
  desc "link newrelic.yml"
  task :symlink do
    run "ln -s #{shared_path}/newrelic.yml #{release_path}/config/newrelic.yml"
  end
end

namespace :ckeditor_assets do
  desc "link ckeditor assets"
  task :symlink do
    run "ln -s #{shared_path}/ckeditor_assets #{release_path}/public/ckeditor_assets"
  end
end

namespace :assets do
  desc "assets precompile"
  task :precompile do
    run "cd #{release_path}; RAILS_ENV=production bundle exec rake assets:clean"
    run "cd #{release_path}; RAILS_ENV=production bundle exec rake assets:precompile --trace"
  end
end

namespace :bundler do
  task :create_symlink, :roles => :app do
    shared_dir = File.join(shared_path, 'bundle')
    release_dir = File.join(current_release, '.bundle')
    run("mkdir -p #{shared_dir} && ln -s #{shared_dir} #{release_dir}")
  end

  task :bundle_new_release, :roles => :app do
    bundler.create_symlink
    run "cd #{release_path} && bundle install --without development:test"
  end

  task :lock, :roles => :app do
    run "cd #{current_release} && bundle lock;"
  end

  task :unlock, :roles => :app do
    run "cd #{current_release} && bundle unlock;"
  end
end

# Create the task to send the notification
namespace :deploy do
  desc "Email notifier"
  task :notify do
    Notifier.deploy_notification(self).deliver
  end
end
