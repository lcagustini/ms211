set :ip_address , "200.98.140.222"
set :host, "alpex.com.br"
# SSH SETTINGS
set :user , "deployer"
set :deploy_to, "/var/www/#{application}"
set :shared_directory, "#{deploy_to}/shared"
set :use_sudo, false
set :group_writable, true
default_run_options[:pty] = true
# ROLES
role :app, ip_address
role :web, ip_address
role :db,  ip_address, :primary => true

# TASKS
namespace :deploy do
  # Restart passenger on deploy
  desc "Restarting mod_rails with restart.txt"
  task :restart, :roles => :app, :except => { :no_release => true } do
    run "touch #{current_path}/tmp/restart.txt"
  end

  [:start, :stop].each do |t|
    desc "#{t} task is a no-op with mod_rails"
    task t, :roles => :app do ; end
  end
end

