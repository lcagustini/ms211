require "action_mailer"

ActionMailer::Base.delivery_method = :smtp
ActionMailer::Base.smtp_settings = {
    :address              => "smtp.gmail.com",
    :port                 => 587,
    :domain               => 'alpex.net.br',
    :user_name            => 'alpexaluminio',
    :password             => 'intranet21',
    :authentication       => 'plain',
    :enable_starttls_auto => true
}

class Notifier < ActionMailer::Base
  default :from => "noreply@alpex.com.br"

  def deploy_notification(cap_vars)
    now = Time.now
    msg = "Performed a deploy operation on #{now.strftime("%m/%d/%Y")} at #{now.strftime("%I:%M %p")} to #{cap_vars.host}"
    
    mail(:to => cap_vars.notify_emails, 
         :subject => "Deployed #{cap_vars.application}") do |format|
      format.text { render :text => msg}
      format.html { render :text => "<p>" + msg + "<\p>"}
    end
  end
end
