# application domain
set :ip_address , "192.168.33.10"
# SSH SETTINGS
# ROLES
role :app, ip_address
role :web, ip_address
role :db,  ip_address, :primary => true

set :user , "vagrant"
set :group, "vagrant"
set :deploy_to, "/var/www/massiveapp"
set :shared_directory, "#{deploy_to}/shared"
set :use_sudo, false
set :group_writable, true
default_run_options[:pty] = true

namespace :deploy do
  task(:start) {}
  task(:stop) {}
  task(:restart, :roles => :app, :except => {:no_release => true}){}
end

deploy.task :restart, :roles => :app do
end

namespace :unicorn do
  desc "Restart unicorn"
  task :restart, :roles => :app do
    daemon(:unicorn, :restart)
  end

  desc "Stop unicorn"
  task :stop, :roles => :app do
    daemon(:unicorn, :stop)
  end

  desc "Start unicorn"
  task :start, :roles => :app do
    daemon(:unicorn, :start)
  end
end
