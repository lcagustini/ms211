AlpexSite::Application.routes.draw do
  mount Ckeditor::Engine => '/ckeditor'
  devise_for :users

  root :to => "home#index"


  match 'budget_forms' => 'budget_forms#new', :as => 'budget_forms', :via => :get
  match 'budget_forms' => 'budget_forms#create', :as => 'budget_forms', :via => :post

  match 'catalog_forms' => 'catalog_forms#new', :as => 'catalog_forms', :via => :get
  match 'catalog_forms' => 'catalog_forms#create', :as => 'catalog_forms', :via => :post

  resources :send_page_queues, :only => [:create]
  resources :send_page, :only => [:index, :new, :create]
  resources :newsletter, :contacts, :sac, :resumes, :only => [:new, :create]
  resources :sitemap, :sector_events, :alpex_events, :search, :advanced_search, :lmes, :only => [:index]
  resources :news, :gallery, :sustainability_actions, :only => [:index, :show]
 
  scope "/categories" do
    resources :categories_apa, :only => [:index, :show], :path => "apa"
    resources :categories_ape, :only => [:index, :show], :path => "ape"
  end

  scope "/products" do
    resources :products_introduction, :only => [:index], :path => "introduction"
    
    resources :products_apa, :only => [:show], :path => "apa" do
      post :set_budget_basket, :on => :collection
      post :set_send_to_friend_basket, :on => :collection
    end

    resources :products_ape, :only => [:show], :path => "ape" do
      post :set_budget_basket, :on => :collection
      post :set_send_to_friend_basket, :on => :collection
    end
  end

  scope "/releases" do
    resources :releases_all, :only => [:index], :path => "all"
    resources :releases_apa, :only => [:index], :path => "apa"
    resources :releases_ape, :only => [:index], :path => "ape"
  end

  namespace :admin do
    root :to => "dashboard#index"

    resources :news, :events, :pages, :lmes, :sustainabilities, :except => [:show]  do
      collection do
        delete :destroy_selection
      end
    end 

    resources :resumes, :site_contacts, :only => [:index, :show]
    resources :newsletters, :only => [:index]

    scope "/categories" do
      resources :categories_apa, :except => [:show], :path => "apa"
      resources :categories_ape, :except => [:show], :path => "ape"
    end

    scope "/products" do
      resources :products_apa, :except => [:show], :path => "apa" do
        post :sort, :on => :collection
        delete :destroy_selection, :on => :collection

        resources :product_apa_collections, :except => [:show] do
          resources :product_apa_associations, :except => [:show]
        end

        resources :product_apa_photos, :except => [:show] do
          post :sort, :on => :collection
        end
      end 

      resources :products_ape, :except => [:show], :path => "ape" do
        post :sort, :on => :collection
        delete :destroy_selection, :on => :collection

        resources :product_ape_photos, :except => [:show] do
          post :sort, :on => :collection
        end
      end
    end
    
    resources :events, :except => [:show] do
      resources :event_photos, :except => [:show] do
        post :sort, :on => :collection
      end
    end

    resources :users, :except => [:show] do
      resources :changesets, :only => [:index]
    end
  end

  # Carregando todas as rotas de Page no "root_path"
  begin
    Page.all.each do |page|
      match page.slug => "pages#show", :id => page.id, :as => page.slug_normalized
    end
  rescue
    Rails.logger.error "Can't load pages in routes." 
  end

  #match "/categories/apa", :to => redirect("/categories/apa/8-linha-moveleira")

  match "/budget_form", :to => redirect("/budget_forms")
  match "/unidade-ape", :to => redirect("/alpex-produtos-extrudados")
  match "/unidade-apa", :to => redirect("/alpex-produtos-acabados")

  #Gerais
  match "/Default.aspx", :to => redirect("/")
  match "/links-alpex.aspx", :to => redirect("/links-uteis")
  match "/sitemap-alpex.aspx", :to => redirect("/sitemap")
  match "/solicite-seu-catalogo.aspx", :to => redirect("/catalog_forms")
  match "/cotacao-alpex.aspx", :to => redirect("/lmes")

  #Sobre a Alpex 
  match "/historia-alpex.aspx", :to => redirect("/historia")
  match "/unidades-alpex.aspx", :to => redirect("/unidades")
  match "/sustentabilidade-alpex.aspx", :to => redirect("/sustentabilidade")
  match "/sobre-o-aluminio.aspx", :to => redirect("/sobre-o-aluminio")
  match "/certificados-iso-9001.html", :to => redirect("/certificados-iso")

  #Unidades  
  match "/unidades-alpex.aspx", :to => redirect("/unidades")
  match "/unidade-apa.aspx", :to => redirect("/unidade-apa")
  match "/unidade-ape.aspx", :to => redirect("/unidade-ape")

  #Produtos
  match "/produtos-extrudados.aspx", :to => redirect("/categories/ape")
  match "/produtos-acabados.aspx", :to => redirect("/categories/apa")
          
  #Lançamentos
  match "/lancamentos-alpex.aspx", :to => redirect("/releases/all")
  match "/lancamentos-extrudados.aspx", :to => redirect("/releases/ape")
  match "/lancamentos-acabados.aspx", :to => redirect("/releases/apa")

  #Sala de Imprensa
  match "/noticias-do-setor.aspx", :to => redirect("/news")
  match "/noticias-da-alpex.aspx", :to => redirect("/news")
  match "/banco-de-imagens.aspx", :to => redirect("/gallery")
  match "/assessoria-de-imprensa.aspx", :to => redirect("/assessoria-de-imprensa")

  #Eventos
  match "/agenda-do-setor.aspx", :to => redirect("/sector_events")
  match "/agenda-da-alpex.aspx", :to => redirect("/alpex_events")
  match "/galeria-de-fotos.aspx", :to => redirect("/gallery")

  #Contato
  match "/sac-alpex.aspx", :to => redirect("/sac")
  match "/fale-conosco.aspx", :to => redirect("/contacts/new")
  match "/como-chegar.aspx", :to => redirect("/como-chegar")
  match "/trabalhe-conosco.aspx", :to => redirect("/resumes/new")
  match "/orcamento-alpex.aspx", :to => redirect("/budget_forms")

  #Notícias do Setor
  match "/ver-noticias-do-setor.aspx?UID=30", :to => redirect("/news")
  match "/ver-noticias-do-setor.aspx?UID=9", :to => redirect("/news")
  match "/ver-noticias-do-setor.aspx?UID=8", :to => redirect("/news") 

  #Notícias da Alpex
  match "/ver-noticias-da-alpex.aspx?UID=67", :to => redirect("/news/30")
  match "/ver-noticias-da-alpex.aspx?UID=66", :to => redirect("/news/31")
  match "/ver-noticias-da-alpex.aspx?UID=65", :to => redirect("/news/32")
  match "/ver-noticias-da-alpex.aspx?UID=64", :to => redirect("/news/33")
  match "/ver-noticias-da-alpex.aspx?UID=63", :to => redirect("/news/34")
  match "/ver-noticias-da-alpex.aspx?UID=62", :to => redirect("/news/35") 
  match "/ver-noticias-da-alpex.aspx?UID=61", :to => redirect("/news/36")
  match "/ver-noticias-da-alpex.aspx?UID=60", :to => redirect("/news/36")
  match "/ver-noticias-da-alpex.aspx?UID=59", :to => redirect("/news/38")
  match "/ver-noticias-da-alpex.aspx?UID=58", :to => redirect("/news/39")
  match "/ver-noticias-da-alpex.aspx?UID=57", :to => redirect("/news/40")
  match "/ver-noticias-da-alpex.aspx?UID=56", :to => redirect("/news/41")
  match "/ver-noticias-da-alpex.aspx?UID=55", :to => redirect("/news/42")
  match "/ver-noticias-da-alpex.aspx?UID=54", :to => redirect("/news/43")
  match "/ver-noticias-da-alpex.aspx?UID=53", :to => redirect("/news/44")
  match "/ver-noticias-da-alpex.aspx?UID=52", :to => redirect("/news/45")
  match "/ver-noticias-da-alpex.aspx?UID=51", :to => redirect("/news/46")
  match "/ver-noticias-da-alpex.aspx?UID=50", :to => redirect("/news/47")
  match "/ver-noticias-da-alpex.aspx?UID=49", :to => redirect("/news/48")
  match "/ver-noticias-da-alpex.aspx?UID=48", :to => redirect("/news/49")
  match "/ver-noticias-da-alpex.aspx?UID=47", :to => redirect("/news/50")
  match "/ver-noticias-da-alpex.aspx?UID=45", :to => redirect("/news/52")
  match "/ver-noticias-da-alpex.aspx?UID=44", :to => redirect("/news/51")
  match "/ver-noticias-da-alpex.aspx?UID=43", :to => redirect("/news/53") 

  # Produtos Extrudados 
  #Acessórios e Arremates http://alpex-site.internetsistemas.com.br/categories/ape/31-acabamento
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=2&Categ=1&SubCateg=", :to => redirect("/categories/ape/31-acabamento")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=2&Categ=2&SubCateg=", :to => redirect("/categories/ape/39-construcao")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=2&Categ=3&SubCateg=", :to => redirect("/categories/ape/25-carpete")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=2&Categ=4&SubCateg=", :to => redirect("/categories/ape/98-dobradica")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=2&Categ=5&SubCateg=", :to => redirect("/categories/ape/77-veda-porta")

  #Box
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=6&SubCateg=", :to => redirect("/categories/ape/88-box-bx-frisado")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=7&SubCateg=", :to => redirect("/categories/ape/107-box-bx-liso")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=8&SubCateg=", :to => redirect("/categories/ape/71-box-acrilico")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=9&SubCateg=", :to => redirect("/categories/ape/75-box-liso")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=10&SubCateg=", :to => redirect("/categories/ape/80-sanfonado")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=11&SubCateg=", :to => redirect("/categories/ape/138-sacada")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=12&SubCateg=1", :to => redirect("/categories/ape/89-box-vidro-10-mm")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=12&SubCateg=2", :to => redirect("/categories/ape/117-box-vidro-6-mm")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=3&Categ=12&SubCateg=3", :to => redirect("/categories/ape/62-box-vidro-8-mm")

  #Divisórias
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=4&Categ=13&SubCateg=", :to => redirect("/categories/ape/63-divisoria")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=4&Categ=14&SubCateg=", :to => redirect("/categories/ape/29-teto")

  #Esquadrias
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=15&SubCateg=", :to => redirect("/categories/ape/136-brise")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=16&SubCateg=", :to => redirect("/categories/ape/34-janela-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=17&SubCateg=", :to => redirect("/categories/ape/59-contramarco-arremates")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=18&SubCateg=", :to => redirect("/categories/ape/133-pele-de-vidro")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=19&SubCateg=", :to => redirect("/categories/ape/105-corrimao")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=22&SubCateg=", :to => redirect("/categories/ape/116-janela")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=24&SubCateg=", :to => redirect("/categories/ape/127-linha-28")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=26&SubCateg=", :to => redirect("/categories/ape/113-linha-42")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=27&SubCateg=", :to => redirect("/categories/ape/137-modulo-pratico")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=28&SubCateg=", :to => redirect("/categories/ape/137-modulo-pratico")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=29&SubCateg=", :to => redirect("/categories/ape/103-grade") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=30&SubCateg=", :to => redirect("/categories/ape/136-brise")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=31&SubCateg=", :to => redirect("/categories/ape/87-tela-mosquiteira")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=32&SubCateg=", :to => redirect("/categories/ape/42-vitrine")

  #Linha 16
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=20&SubCateg=4", :to => redirect("/categories/ape/52-basculante")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=20&SubCateg=5", :to => redirect("/categories/ape/76-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=20&SubCateg=6", :to => redirect("/categories/ape/76-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=20&SubCateg=7", :to => redirect("/categories/ape/74-veneziana")
  
  #Linha 20
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=21&SubCateg=8", :to => redirect("/categories/ape/123-linha-20") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=21&SubCateg=9", :to => redirect("/categories/ape/123-linha-20") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=21&SubCateg=83", :to => redirect("/categories/ape/123-linha-20") 
  
  #Linha 25
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=10", :to => redirect("/categories/ape/52-basculante") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=11", :to => redirect("/categories/ape/50-complementos") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=12", :to => redirect("/categories/ape/51-janela-maxim-ar") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=13", :to => redirect("/categories/ape/66-janela-e-porta-decorrer") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=14", :to => redirect("/categories/ape/66-janela-e-porta-decorrer") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=15", :to => redirect("/categories/ape/66-janela-e-porta-decorrer") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=16", :to => redirect("/categories/ape/66-janela-e-porta-decorrer") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=23&SubCateg=17", :to => redirect("/categories/ape/74-veneziana") 

  #Linha 30
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=18", :to => redirect("/categories/ape/139-complemento")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=19", :to => redirect("/categories/ape/51-janela-maxim-ar")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=20", :to => redirect("/categories/ape/57-janela-e-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=21", :to => redirect("/categories/ape/57-janela-e-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=22", :to => redirect("/categories/ape/57-janela-e-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=23", :to => redirect("/categories/ape/57-janela-e-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=24", :to => redirect("/categories/ape/57-janela-e-porta-de-correr")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=5&Categ=25&SubCateg=18", :to => redirect("/categories/ape")

  #Standart
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=35&SubCateg=", :to => redirect("/categories/ape/46-perfil-t")
              
  #Barra
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=33&SubCateg=25", :to => redirect("/categories/ape/22-barra-chata")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=33&SubCateg=26", :to => redirect("/categories/ape/38-barra-chata-c-arred")
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=33&SubCateg=27", :to => redirect("/categories/ape/110-barra-chata-frisada")
  
  #Cantoneira
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=34&SubCateg=28", :to => redirect("/categories/ape/112-cl-abas-desiguais") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=34&SubCateg=29", :to => redirect("/categories/ape/18-cl-abas-iguais") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=34&SubCateg=30", :to => redirect("/categories/ape/125-cl-abas-iguais-cantos-arred") 
  
  #Perfil U
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=36&SubCateg=31", :to => redirect("/categories/ape/73-u-abas-desiguais") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=36&SubCateg=32", :to => redirect("/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=36&SubCateg=32")              
  
  #Tubo
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=37&SubCateg=33", :to => redirect("/categories/ape/13-standard") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=37&SubCateg=34", :to => redirect("/categories/ape/36-tubo-redondo") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=37&SubCateg=35", :to => redirect("/categories/ape/72-tubo-retangular") 
  
  #Vergalhão
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=38&SubCateg=84", :to => redirect("/categories/ape/84-verg-quadrado") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=38&SubCateg=85", :to => redirect("/categories/ape/84-verg-quadrado") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=38&SubCateg=86", :to => redirect("/categories/ape/35-verg-redondo") 
  match "/ver-produtos-extrudados.aspx?UID=7&UBS=6&Categ=38&SubCateg=87", :to => redirect("/categories/ape/45-verg-sextavado") 

  #Decoração
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=39&SubCateg=", :to => redirect("/categories/ape/83-celular")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=40&SubCateg=", :to => redirect("/categories/ape/69-horizontal")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=41&SubCateg=", :to => redirect("/categories/ape/118-evidence")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=42&SubCateg=", :to => redirect("/categories/ape/95-rolo")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=43&SubCateg=", :to => redirect("/categories/ape/124-romana")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=44&SubCateg=", :to => redirect("/categories/ape/17-vertical")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=45&SubCateg=", :to => redirect("/categories/ape/99-toldo")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=46&SubCateg=", :to => redirect("/categories/ape/41-trilho-standart")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=47&SubCateg=", :to => redirect("/categories/ape/94-trilho-europeu")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=8&Categ=48&SubCateg=", :to => redirect("/categories/ape/111-trilho-painel")

  #Linha Moveleira
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=49&SubCateg=", :to => redirect("/categories/ape")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=50&SubCateg=", :to => redirect("/categories/ape/109-cabideiro")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=51&SubCateg=", :to => redirect("/categories/ape/130-distanciador")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=52&SubCateg=", :to => redirect("/categories/ape")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=53&SubCateg=", :to => redirect("/categories/ape/90-porta-de-abrir")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=54&SubCateg=", :to => redirect("/categories/ape")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=55&SubCateg=", :to => redirect("/categories/ape/114-prateleira")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=56&SubCateg=", :to => redirect("/categories/ape/67-puxadores")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=57&SubCateg=", :to => redirect("/categories/ape/120-testeira")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=58&SubCateg=", :to => redirect("/categories/ape/68-trilhos-inferior")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=59&SubCateg=", :to => redirect("/categories/ape/68-trilhos-inferior")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=9&Categ=60&SubCateg=", :to => redirect("/categories/ape/91-trilhos-superior")

  #Móveis Urbanos
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=10&Categ=61&SubCateg=", :to => redirect("/categories/ape/92-display")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=10&Categ=62&SubCateg=", :to => redirect("/categories/ape/129-moldura")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=10&Categ=63&SubCateg=", :to => redirect("/categories/ape/131-policarbonato")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=10&Categ=64&SubCateg=", :to => redirect("/categories/ape/86-propaganda")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=10&Categ=65&SubCateg=", :to => redirect("/categories/ape/97-cabinagem")

  #Outras Aplicações
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=66&SubCateg=", :to => redirect("/categories/ape/119-antena")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=67&SubCateg=", :to => redirect("/categories/ape/37-bicicleta")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=68&SubCateg=", :to => redirect("/categories/ape/81-cadeira")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=69&SubCateg=", :to => redirect("/categories/ape/27-dissipador")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=70&SubCateg=", :to => redirect("/categories/ape/")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=71&SubCateg=", :to => redirect("/categories/ape/122-escadahttp://alpex-site.internetsistemas.com.br/categories/ape/126-gancheira")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=72&SubCateg=", :to => redirect("/categories/ape/126-gancheira")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=73&SubCateg=", :to => redirect("/categories/ape/93-luminaria")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=74&SubCateg=", :to => redirect("/categories/ape/48-barco")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=75&SubCateg=", :to => redirect("/categories/ape/21-para-chamas")
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=76&SubCateg=", :to => redirect("/categories/ape/108-patinete") 
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=77&SubCateg=", :to => redirect("/categories/ape/65-rodo") 
  match "/ver-produtos-extrudados.aspx?UID=8&UBS=11&Categ=78&SubCateg=", :to => redirect("/categories/ape/101-hospitalar") 

  #Produtos Acabados
  #Kit Box
  match "/ver-produtos-acabados.aspx?UID=9&UBS=102&Categ=&SubCateg=", :to => redirect("/products/apa/5467-kit-box-acqua")
  match "/ver-produtos-acabados.aspx?UID=9&UBS=103&Categ=&SubCateg=", :to => redirect("/products/apa/5468-kit-box-acqua-plus")

  #Linha Moveleira
  match "/ver-produtos-acabados.aspx?UID=10&UBS=17&Categ=&SubCateg=", :to => redirect("/products/apa/1-linha-belagio")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=18&Categ=&SubCateg=", :to => redirect("/products/apa/8-linha-cristal")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=19&Categ=&SubCateg=", :to => redirect("/products/apa/9-linha-milan")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=20&Categ=&SubCateg=", :to => redirect("/products/apa/10-linha-rimini")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=21&Categ=&SubCateg=", :to => redirect("/products/apa/11-linha-roma")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=79&Categ=&SubCateg=", :to => redirect("/products/apa/12-linha-verona")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=80&Categ=&SubCateg=", :to => redirect("/products/apa/13-linha-light")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=81&Categ=&SubCateg=", :to => redirect("/products/apa/14-porta-de-abrir-basculante")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=82&Categ=&SubCateg=", :to => redirect("/products/apa/14-porta-de-abrir-basculante")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=83&Categ=&SubCateg=", :to => redirect("/products/apa/16-trilho")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=84&Categ=&SubCateg=", :to => redirect("/products/apa/17-travessa")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=85&Categ=&SubCateg=", :to => redirect("/products/apa/26-puxador")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=86&Categ=&SubCateg=", :to => redirect("/products/apa/18-cabideiro")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=87&Categ=&SubCateg=", :to => redirect("/products/apa/19-testeira")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=88&Categ=&SubCateg=", :to => redirect("/products/apa/20-porta-cd-e-dvd")
  match "/ver-produtos-acabados.aspx?UID=10&UBS=89&Categ=&SubCateg=", :to => redirect("/products/apa/21-prateleira-de-calceiro") 
  match "/ver-produtos-acabados.aspx?UID=10&UBS=90&Categ=&SubCateg=", :to => redirect("/products/apa/22-acessorios") 
  match "/ver-produtos-acabados.aspx?UID=10&UBS=91&Categ=&SubCateg=", :to => redirect("/products/apa/23-esquadretas") 
  match "/ver-produtos-acabados.aspx?UID=10&UBS=92&Categ=&SubCateg=", :to => redirect("/products/apa/24-comentarios") 
  match "/ver-produtos-acabados.aspx?UID=10&UBS=93&Categ=&SubCateg=", :to => redirect("/products/apa/25-paineis-decorativos") 

  #Kit Engenharia
  match "/ver-produtos-acabados.aspx?UID=11&UBS=14&Categ=&SubCateg=", :to => redirect("/products/apa/5469-kit-engenharia-8mm") 
  match "/ver-produtos-acabados.aspx?UID=11&UBS=15&Categ=&SubCateg=", :to => redirect("/products/apa/5470-kit-engenharia-10mm")
end
