ActiveRecord::Base.send :include, EnumerateIt
