SITE_CONFIG = YAML.load_file("#{Rails.root.to_s}/config/site_config.yml")[Rails.env]
