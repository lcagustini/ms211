# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AlpexSite::Application.config.secret_token = '7726b9add76a21b1b2f23b12724068c31e113294ae1748d6f7f467376a1fdeae0bf09da6a3abed7a198cb4b3c49d8d89632380c4795aac5e1497f24df28b8990'
