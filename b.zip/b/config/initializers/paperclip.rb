# Load config/paperclip.yml settings
if paperclip_cfg = YAML.load_file("#{Rails.root}/config/paperclip.yml")[Rails.env]
  paperclip_cfg.symbolize_keys!
  
  paperclip_cfg[:s3_credentials] = "#{Rails.root}/config/s3.yml"
  
  # Replace Attachment defaults with configuration ones
  Paperclip::Attachment.default_options.merge!(paperclip_cfg)
end
